// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAiHhhRNRurQf8dBorB2r6mSRgOa6bZu7w",
  authDomain: "recommendation-system-d9250.firebaseapp.com",
  projectId: "recommendation-system-d9250",
  storageBucket: "recommendation-system-d9250.appspot.com",
  messagingSenderId: "912882030048",
  appId: "1:912882030048:web:d3a8725612fd51e4678785"
};

const app = initializeApp(firebaseConfig);
export const storage = getStorage(app);