import dataset from '../datasets/global.dataset'
const interest_fields = dataset.Interest_Fields

const combination = {
    Realistic: ['I', 'A', 'S', 'E', 'C'],
    Investigative: ['R', 'S'],
    Artistic: ['R', 'S', 'E'],
    Social: ['R', 'I', 'A', 'E'],
    Enterprising: ['R', 'A', 'S', 'C'],
    Conventional: ['R', 'E'],
}

const acronym = {
    R: "Realistic",
    I: "Investigative",
    A: "Artistic",
    S: "Social",
    E: "Enterprising",
    C: "Conventional",
}

export const IAAlgorithm = (result) => {
    let i = 0
    let plus = 1
    let iaresult;

    const iasort = result.sort((a, b) => b.score - a.score).slice(0, 3)

    do {
        const ia_array = combination[iasort[i].hip].filter(a => a == iasort[i + plus].hip[0])

        if (ia_array.length != 0) {
            iaresult = [iasort[i].hip, acronym[String(ia_array)]]
            i = -1
        } else if (i == 1) {
            i = 0;
            plus = 2
        } else {
            i++
        }
    } while (i != -1)

    return iaresult
}

export const SATAlgorithm = (result, time) => {
    const data = result[0].satExamResult.score
    
    const algo = ['math', 'science', 'english', 'reading'].map((values, index) => {
        if (values === data[index].subject) {
            const acc = accuracy(data[index].score)         
            const ave = averagetime(data[index].minute, data[index].second, time, 0)
            const eff = efficiency(acc, ave)

            return { subject: values, accuracy: acc, average: ave, efficiency: eff }
        }

        return values
    })

    function accuracy(score) {
        return score / 25
    }
    
    function averagetime(minute, second, setminute, setsecond) {
        return ((setminute - minute) + (setsecond - second) / setminute)
    }

    function efficiency(acc, ave) {
        return (0.6 * acc) + (0.4 * ave) 
    }

    return algo
}

export const course_recommendation = (course, interest, subject) => {
    const sub = subject == 'reading'? 'readingComprehension' :subject
    return course.filter(value=> value.interest == interest && value.coursePercentage[sub] >= 20 )
}
