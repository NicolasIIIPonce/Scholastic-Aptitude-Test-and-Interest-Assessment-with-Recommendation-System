import globalDataset from "../datasets/global.dataset";

export const navbarURL = () => {
    const tabs = globalDataset.Dashboard.Navbar
    const link = location.href.split('/').at(-1);
    const filtertab = tabs.filter(tab => tab.link === link || tab.label === link)
    return filtertab.length === 0 ? " " : filtertab[0].link
}

export function getWindowSize() {
    return {
        width: window.innerWidth,
        height: window.innerHeight
    }
}

export const getUrl = (num) => {
    return location.href.split('/').at(-num);
}

export const changeUrl = (word, In, Out) => {
    return word.replace(' ', '-')
}

export const clearSession = () => {
    sessionStorage.removeItem("math")
    sessionStorage.removeItem("english")
    sessionStorage.removeItem("science")
    sessionStorage.removeItem("reading")
    sessionStorage.removeItem("time")
}

export const getSession = (name) => {
    return JSON.parse(sessionStorage.getItem(name))
}

export function removeExtension(filename) {
    return (
      filename.substring(0, filename.lastIndexOf('.')) || filename
    );
  }