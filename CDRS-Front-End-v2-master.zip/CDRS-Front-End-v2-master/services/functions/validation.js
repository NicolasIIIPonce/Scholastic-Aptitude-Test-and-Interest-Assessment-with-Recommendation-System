import dataset from '../datasets/validations.dataset'

export const validation = (name, value, regex) => {
    const field = dataset[name];
    const { minLength, regexp, label } = field;

    if (value === "") {
        return 'Please fill in this required fields.'
    } else if (value.length < minLength) {
        return `Must be ${name == 'lrn' ? 'exact 12' : 'atleast 8'} numbers`
    } else if (!regexp.test(value) && regex) {
        return label
        // 'Please match the format of creating password.'
    } else {
        return 'success'
    }
}

export const limitation = (name, value) => {
    const field = dataset[name];
    const { maxLength, regexp } = field;
    const noinclude = ['password']

    const expression = regexp != null && !noinclude.includes(name) ? regexp.test(value) : true;

    if(value.length <= maxLength && expression) {
        return true;
    } else {
        return false;
    }
}

export const confirmpass = (password, confirm) => {
    if (confirm === "") {
        return 'Please fill in this required fields.'
    } else if (password === confirm){
        return 'success'
    }else{
        return "Password didn't match"
    }
}

