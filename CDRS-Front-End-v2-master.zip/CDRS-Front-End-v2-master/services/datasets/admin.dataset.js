export default {
    StudentInformation: {
        instructions: {
            id: "studentinformations",
            title: "Student Information",
            subtext: "Students",
            text: "Student",
            add: true,
            edit: false,
        },
        fields: [
            { id: 'lrn', label: 'LRN', },
            { id: 'firstname', label: 'Firstname' },
            { id: 'lastname', label: 'Lastname' },
            { id: 'section', label: 'Section', },
            { id: 'examStatus', label: 'Exam Status', align: 'center' },
            { id: 'accountStatus', label: 'Account Status', align: 'center', type: 1 },
            { id: 'action', label: 'Action', align: 'center' }
        ],
        forms: [
            { id: "_id", title: "Student ID", text: "Enter the student's unique identifier.", inputno: 1, disabled: true },
            { id: "lrn", title: "LRN", text: "Please input the proper format for your Learning Reference Number That was given to you by DEPED (Ex. 501141600721)", inputno: 1 },
            { id: "firstname", title: "Firstname", text: "Please enter a valid first name of the student using only letters. The name should be between 2 and 30 characters long (Ex. Sy, John)", inputno: 1 },
            { id: "lastname", title: "Lastname", text: "Please enter a valid last name of the student using only letters. The name should be between 2 and 30 characters long (Ex. Ngo, Robert)", inputno: 1 },
            { id: "section", title: "Section", text: "Please enter the current section/strand that the student is currently enrolled in (Ex. ICT1, STEM3, HUMMS2)", inputno: 1 },
            { id: "password", title: "Password", text: "Please enter a valid password that contains minimum of 6 letters with combination of uppercase and lowercase letters and numbers (Ex. Iamhandsome123)", inputno: 2 },
            { id: "examStatus", title: "Exam Status", text: "Please select the appropiate Exam status of the student from the dropdown field (Ex. Taken, Not Taken)", inputno: 4 },
            { id: "accountStatus", title: "Account Status", text: "Please select the appropiate account status of the student from the dropdown field (Ex. Active, Not Active)", inputno: 4 },
            { id: "createdAt", title: "created At", text: "Please enter the date and time when the student account was created (Ex. YYYY-MM-DD HH:MM:SS)", inputno: 1, disabled: true },
            { id: "updatedAt", title: "updated At", text: "Please enter the date and time when the student account was updated (Ex. YYYY-MM-DD HH:MM:SS)", inputno: 1, disabled: true },
        ],
        lists: {
            accountStatus: ['Active', 'Inactive'],
            examStatus: ['Exam Taken', 'Not Taken']
        },
        dataform: {
            "lrn": "",
            "firstname": "",
            "lastname": "",
            "section": "",
            "password": "na",
            "examStatus": "Not Taken",
            "accountStatus": "Active"
        },
        SearchList: [
            { id: 'All', label: 'All' },
            { id: 'lrn', label: 'LRN' },
            { id: 'firstname', label: 'FirstName' },
            { id: 'lastname', label: 'LastName' },
            { id: 'section', label: 'Section' },
        ]
    },
    CourseInformation: {
        instructions: {
            id: "courseinformation",
            title: "Course Information",
            subtext: "Courses",
            text: "Course",
            add: true,
            edit: false
        },
        fields: [
            { id: '_id', label: 'CID' },
            { id: 'courseName', label: 'Course Name' },
            { id: 'acronym', label: 'Acronym' },
            { id: 'field', label: 'Field', },
            { id: 'action', label: 'Action', align: 'center' }
        ],
        forms: [
            { id: "_id", title: "Course Information ID", text: "lorem ipsum", disabled: true, inputno: 1 },
            { id: "field", title: "Field", text: "Enter the general field or discipline of the course. For example: Engineering, Medicine, Business, Literature, etc.", inputno: 4 },
            { id: "acronym", title: "Acronym", text: "Enter the abbreviated form or acronym of the course name. It is typically formed by taking the initial letters of each word in the course name.", inputno: 1 },
            { id: "courseName", title: "Course Name", text: "Enter the official name or title of the course. Starts with its field then the course name. Example (Bachelor of Science in Information Technology)", inputno: 1 },
            { id: "description", title: "Description", text: "Provide additional details or information about the course. This may include course objectives, prerequisite requirements, course content, learning outcomes, and other relevant information that will help students understand the course.", inputno: 3 },
            { id: "headerPicture", title: "Header Picture", text: "Upload or select a suitable image or graphic to be used as the header picture. Choose an image that represents the course theme, subject, or concept effectively. Ensure that the image is of high quality and appropriate for the course content.", inputno: 5 },
            { id: "interest", title: "Interest", text: "Allow users to select an interest field that aligns with the course. Provide a list of interest fields related to the course content, such as Technology, Business, Health Sciences, Arts, etc.", inputno: 4 },
            { id: "courseJob", title: "Job", text: "Enter the job or career opportunities associated with the course. This could include specific roles, professions, or industries where individuals who have completed the course can find employment. Provide relevant information about potential career paths and opportunities that the course can lead to.", inputno: 6, },
            { id: "CoursePercentage", title: "Course Percentage", text: "Assign a percentage to each subject to indicate its relative importance or relevance to the course. Divide a total of 100% among the four subjects based on their significance in relation to the course. Consider factors such as the depth of coverage, core concepts, and skills required for each subject.", inputno: 7 },
        ],
        lists: {
            field: [
                "Humanities",
                "Social Science",
                "Natural Sciences",
                "Formal Sciences",
                "Professions and Applied Sciences",
                "Health Sciences",
                "Education",
                "Engineering",
                "Media and Communication",
                "Public Administration",
                "Transportation",
                "Nutrition",
            ],
            interest: [
                "Health Science",
                "Human Service",
                "Law & Public Safety",
                "Arts & Communications",
                "Hospitality & Tourism",
                "Education & Training",
                "Agriculture",
                "Information Technology",
                "Science, Technology & Math",
                "Marketing & Sales",
                "Government",
                "Business & Management",
                "Finance",
                "Architecture & Construction",
                "Manufacturing",
                "Transportation",
            ]
        },
        dataform: {
            "field": "Humanities",
            "acronym": "",
            "courseName": "",
            "description": "",
            "headerPicture": "",
            "interest": "Health Science",
            "courseJob": [
                { "jobName": "", "description": "" },
                { "jobName": "", "description": "" },
                { "jobName": "", "description": "" },
            ],
            "coursePercentage": {
                "math": 0,
                "science": 0,
                "english": 0,
                "readingComprehension": 0,
            }
        },
        SearchList: [
            { id: 'All', label: 'All' },
            { id: '_id', label: 'CID' },
            { id: 'courseName', label: 'Course Name' },
            { id: 'acronym', label: 'Acronym' },
            { id: 'field', label: 'Field' },
        ]
    },
    Examination: {
        instructions: {
            id: "Examination",
            title: "Examination",
            subtext: "Exam Information",
            text: "Examination",
            add: true,
            edit: false
        },
        fields: [
            { id: '_id', label: 'Exam ID', },
            { id: 'section', label: 'Section' },
            { id: 'accessCode', label: 'Access Code' },
            { id: 'minute', label: 'Minutes', },
            { id: 'startDate', label: 'Start Date' },
            { id: 'endDate', label: 'End Date' },
            { id: 'status', label: 'Status' },
            { id: 'action', label: 'Action', align: 'center' }
        ],
        forms: [
            { id: "_id", title: "Exam ID", text: "Enter the Exam unique identifier.", inputno: 1, disabled: true },
            { id: "section", title: "Section", text: "Enter the student's current section/strand. (Ex. ICT1, STEM3, HUMMS2)", inputno: 1 },
            { id: "accessCode", title: "Access Code", text: "Please enter the access code for the Exam (Ex. 1234, abcd)", inputno: 2, random: true },
            { id: "minute", title: "Minute", text: "Please enter the number of minute for the Exam (Ex. 10 Minute)", inputno: 4 },
            { id: "startDate", title: "Start Date", text: "Please fill up the date on which the access code becomes active. After this date, the access code can be used to access the Exam. (YYYY-MM-DD)", inputno: 8 },
            { id: "endDate", title: "End Date", text: "Please fill up the date on which the access code expires. After this date, the access code can no longer be used to access the exam (YYYY-MM-DD)", inputno: 8 },
            { id: "status", title: "Status", text: "Enter the status of the Exam (Ex. Active, Not Active).", inputno: 4 },
            { id: "createdAt", title: "created At", text: "Please provide timestamp that indicates when a record was first created (Ex. YYYY-MM-DD HH:MM:SS)", inputno: 1, disabled: true },
            { id: "updatedAt", title: "updated At", text: "Please provide timestamp that indicates when a record was last modified (Ex. YYYY-MM-DD HH:MM:SS)", inputno: 1, disabled: true },
        ],
        lists: {
            minute: [10, 20, 30, 40, 50],
            status: ['Active', 'Inactive']
        },
        dataform: {
            "section": "",
            "accessCode": "",
            "minute": 10,
            "startDate": "",
            "endDate": "",
            "status": "Active",
        },
        SearchList: [
            { id: 'All', label: 'All' },
            { id: 'section', label: 'Section' },
            { id: 'accessCode', label: 'Access Code' },
        ]
    },
    subjects: {
        instructions: {
            id: "Examination",
            title: "Exam Questions",
            subtext: "Exam Questions",
            text: "Question",
            add: true,
            edit: false
        },
        fields: [
            { id: '_id', label: 'ID', },
            { id: 'question', label: 'Question' },
            { id: 'choiceA', label: 'Choice A' },
            { id: 'choiceB', label: 'Choice B' },
            { id: 'choiceC', label: 'Choice C' },
            { id: 'choiceD', label: 'Choice D' },
            { id: 'answer', label: 'Answer' },
            { id: 'action', label: 'Action' }
        ],
        forms: [
            { id: "_id", title: "Question ID", text: "Enter the question unique identifier.", inputno: 1, disabled: true },
            { id: "question", title: "Question", text: "Write a clear and concise question that assesses the student's knowledge or understanding of the topic.", inputno: 3 },
            { id: "choiceA", title: "Choice A", text: "The answer should be complete and accurate.", inputno: 1 },
            { id: "choiceB", title: "Choice B", text: "The answer should be complete and accurate.", inputno: 1 },
            { id: "choiceC", title: "Choice C", text: "The answer should be complete and accurate.", inputno: 1 },
            { id: "choiceD", title: "Choice D", text: "The answer should be complete and accurate.", inputno: 1 },
            { id: "answer", title: "Answer", text: "Provide the correct answer.", inputno: 1 },
            { id: "createdAt", title: "created At", text: "Provide timestamp that indicates when a record was first created (Ex. YYYY-MM-DD HH:MM:SS)", inputno: 1, disabled: true },
            { id: "updatedAt", title: "updated At", text: "Provide timestamp that indicates when a record was last modified (Ex. YYYY-MM-DD HH:MM:SS)", inputno: 1, disabled: true },
        ],
        lists: {
            minute: [10, 20, 30, 40, 50],
            status: ['Active', 'Inactive']
        },
        dataform: {
            "question": "",
            "choiceA": "",
            "choiceB": "",
            "choiceC": "",
            "choiceD": "",
            "answer": "",
        },
        SearchList: [
            { id: 'All', label: 'All' },
            { id: '_id', label: 'Exam ID' },
        ]
    },
    IAQuestion: {
        instructions: {
            id: "Examination",
            title: "IA Questions",
            subtext: "Interest Assessment Questions",
            text: "IA Question",
            add: true,
            edit: false
        },
        fields: [
            { id: '_id', label: 'IAID', },
            { id: 'question', label: 'Question' },
            { id: 'hip', label: 'HIP' },
            { id: 'action', label: 'Action', align: 'center' }
        ],
        forms: [
            { id: "_id", title: "Question ID", text: "Enter the question unique identifier.", inputno: 1, disabled: true },
            { id: 'question', title: 'Question', text: 'Please provide information about your interests, activities, and values (Ex. Do you love painting?)', inputno: 1 },
            { id: 'hip', title: 'HIP', text: 'Please provide the Holland Interest Profile(Ex. Realistic,Investigative,Artistic,Social,Enterprising,Conventional)', inputno: 4 },
            { id: "createdAt", title: "created At", text: "Provide timestamp that indicates when a record was first created (Ex. YYYY-MM-DD HH:MM:SS)", inputno: 1, disabled: true },
            { id: "updatedAt", title: "updated At", text: "Provide timestamp that indicates when a record was last modified (Ex. YYYY-MM-DD HH:MM:SS)", inputno: 1, disabled: true },
        ],
        lists: {
            hip: [
                "Realistic",
                "Investigative",
                "Artistic",
                "Social",
                "Enterprising",
                "Conventional",
            ]
        },
        dataform: {
            "question": "",
            "hip": "Realistic",
        },
        SearchList: [
            { id: 'All', label: 'All' },
            { id: '_id', label: 'IAID' },
            { id: 'question', label: 'Question' },
            { id: 'hip', label: 'HIP' },
        ]
    },
    satExamResult: {
        instructions: {
            id: "satExamResult",
            title: "SAT Result",
            subtext: "Students SAT Result",
            text: "",
            add: false,
            edit: false
        },
        fields: [
            { id: 'lrn', label: 'LRN', },
            { id: 'math', label: 'Math' },
            { id: 'english', label: 'English' },
            { id: 'science', label: 'Science', },
            { id: 'reading', label: 'Reading Comprehension', },
            { id: 'total', label: 'Total', },
            { id: 'result', label: 'Result' },
        ],
        SearchList: [
            { id: 'All', label: 'All' },
            { id: 'lrn', label: 'LRN' },
        ]
    },
    iaExamResult: {
        instructions: {
            id: "satExamResult",
            title: "SAT Result",
            subtext: "Students SAT Result",
            text: "",
            add: false,
            edit: false
        },
        fields: [
            { id: 'lrn', label: 'LRN', },
            { id: 'Realistic', label: 'Realistic' },
            { id: 'Investigative', label: 'Investigative' },
            { id: 'Artistic', label: 'Artistic', },
            { id: 'Social', label: 'Social', },
            { id: 'Enterprising', label: 'Enterprising', align: 'center' },
            { id: 'Conventional', label: 'Conventional', align: 'center' },
            { id: 'Result_A', label: 'Result A', align: 'center' },
            { id: 'Result_B', label: 'Result B', align: 'center' },
        ],
        SearchList: [
            { id: 'All', label: 'All' },
            { id: 'lrn', label: 'LRN' },
        ]
    },
    overallResult: {
        instructions: {
            id: "satExamResult",
            title: "SAT Result",
            subtext: "Students SAT Result",
            text: "",
            add: false,
            edit: false
        },
        fields: [
            { id: 'lrn', label: 'LRN', },
            { id: 'Math', label: 'Math efficiency' },
            { id: 'Science', label: 'Science efficiency' },
            { id: 'English', label: 'English efficiency', },
            { id: 'Reading', label: 'Reading Comprehension efficiency', },
        ],
        SearchList: [
            { id: 'All', label: 'All' },
            { id: 'lrn', label: 'LRN' },
        ]
    },

}