export default {
    Dashboard: {
        Navbar: [
            { label: 'Dashboard', link: '' },
            { label: 'Course', link: 'Course-Directory' },
            { label: 'IA Information', link: 'IA-Information' },
            { label: 'Examination', link: 'Examination' },
            { label: 'Help', link: 'Help' },
        ]
    },
    MainTab: {
        Containers: [
            {
                title: 'User Profile',
                text: 'View and Edit your personal student information',
                link: 'Profile/Account',
                buttontext: 'View Profile',
                iconcolor: '#1e88e5',
            },
            {
                title: "Course Directory",
                text: "Search and Read information about college courses",
                link: "Course-Directory",
                buttontext: "View Courses",
                iconcolor: '#ea638c',
            },

            {
                title: "Examination",
                text: "Answer the examination and view your results after",
                link: "Examination",
                buttontext: "View Exam",
                iconcolor: '#52b788',
            },

            {
                title: "Help Section",
                text: "Get Assistance and knowledge as you use the website",
                link: "Help",
                buttontext: "Learn More",
                iconcolor: '#ffd100',
            },
        ]
    },
    IAInformation: {
        header: [
            {
                id: 'h1',
                title: 'What is Interest Assessment ?',
                text: 'An interest assessment can help you learn which careers might be the best fit for you. It is meant to help you find careers that you might enjoy. It will give you a broad list of career options that match your interests. Skills assessments can also match your skills to careers. Holland codes help you match what you like to do with appropriate careers. To figure out which careers will suit you, you first must understand your own interest profile. You can do so by taking a Holland Code assessment. Then, once you have your scores in each of the six interest areas, you can do a search to find careers that match your top interests.',
            },
            {
                id: 'h2',
                title: 'Holland Interest Assessment',
                text: "This interest assessment is based on Holland's Inventory of Basic Interests, also sometimes called the RIASEC assessment. It shows that people with similar personal interests often like the same types of careers. Each of the 6 interest areas describes a broad field of similar work tasks and activities. Interest areas are also descriptive of people: their values, motivations, and preferences. For each interest area, there is a collection of typical job tasks, as well as a description of the type of person who would be interested in doing those sorts of tasks.",
            },
        ],
        ia: [
            {
                id: 1,
                label: 'Realistic',
                title: 'Realistic people are DOERS',
                personality: 'You are practical, reserved, curious, and persistent. You are good at solving problems. You prefer to work with things like machines, tools, and greenery.',
                hobies: 'You like to work with your hands to build or fix things. You like to play sports and be physically active. You prefer outdoor activities. You are good at electronics, mechanics, engineering, lab work, farming, or carpentry work.'
            },
            {
                id: 2,
                label: 'Investigative',
                title: 'Investigative people are THINKERS',
                personality: "You are curious, observant, and analytical. You're like to work independently rather than on a team.",
                hobies: "You are good at math or science. You may enjoy analyzing data. You like to solve puzzles and figure out difficult problems. You enjoy reading, investigating and research, or using scientific or computer equipment."
            },
            {
                id: 3,
                label: 'Artistic',
                title: 'Artistic people are CREATORS',
                personality: 'You are intuitive, sensitive, and imaginative. You prefer to work in unstructured situations. You like to work where you can use your creativity and come up with new ideas.',
                hobies: " You enjoy performing or creating visual arts. You might like to go to museums. You may like to attend concerts or plays. You might enjoy fashion, creative writing, drawing, and creating new things in a variety of settings."
            },
            {
                id: 4,
                label: 'Social',
                title: 'Social people are HELPERS',
                personality: 'You are friendly, empathetic, cooperative, and responsible. You like to work directly with people rather than things. You prefer to work as part of a team and sometimes lead or coordinate activities.',
                hobies: "You enjoy teaching, counseling, or curing others. You might be a good public speaker or trainer. You may like playing team sports. You like to work with children, the elderly, people with special needs, or diverse populations."
            },
            {
                id: 5,
                label: 'Enterprising',
                title: 'Enterprising people are PERSUADERS',
                personality: 'You are enthusiastic, assertive, adventurous, and talkative. You like to start new projects and make decisions that affect others. You like to work with other people and often prefer to be in leadership positions.',
                hobies: 'You enjoy influencing, persuading, and performing. You are good at selling things, promoting ideas, and managing people. You may enjoy starting your own business or running for political office.'
            },
            {
                id: 6,
                label: 'Conventional',
                title: 'Conventional people are ORGANIZERS',
                personality: 'You are respectful, orderly, persistent, and practical. You like working with numbers and are good at following instructions. You like working in structured situations with set goals and deadlines.',
                hobies: 'You are detail-oriented and enjoy working with data. You are good at following budgets and creating reports. You like to make sure that systems and projects work efficiently and effectively.'
            },
        ],
        lower: {
            id: 'l1',
            title: 'Matching Interest Types to Career Clusters',
            text: "All 16 career clusters are divided by interest types below. Clusters are listed more than once when occupations match different Holland interest types. Find occupations that match your interests by clicking on the clusters listed under interest types."
        },
        career: [
            {
                id: 'c1',
                columntitle: 'Realistic',
                columntext: ['Agriculture', 'Architecture & Construction', 'Health Science', 'Hospitality & Tourism',
                    'Information Technology', 'Law & Public Safety', 'Manufacturing', 'Science, Technology, & Math', 'Transportation']
            },
            {
                id: 'c2',
                columntitle: 'Investigative',
                columntext: ['Health Science', 'Information Technology', 'Science, Technology, & Math']
            },
            {
                id: 'c3',
                columntitle: 'Artistic',
                columntext: ['Arts & Communications', 'Education & Training', 'Marketing & Sales']
            },
            {
                id: 'c4',
                columntitle: 'Social',
                columntext: ['Education & Training', 'Government', 'Health Science', 'Human Services', 'Law & Public Safety', 'Marketing & Sales']
            },
            {
                id: 'c5',
                columntitle: 'Enterprising',
                columntext: ['Arts & Communications', 'Business & Management', 'Finance',
                    'Government', 'Hospitality & Tourism', 'Law & Public Safety'
                    , 'Marketing & Sales']
            },
            {
                id: 'c6',
                columntitle: 'Conventional',
                columntext: ['Architecture & Construction', 'Business & Management', 'Finance', 'Health Science', 'Manufacturing', 'Marketing & Sales', 'Transportation']
            },
        ],
        colors:
            [
                '0, 150, 199',
                '157, 78, 221',
                '105, 185, 110',
                '255, 166, 43',
                '219, 81, 76',
                '251, 133, 0',
            ]
    },
    HelpTab: {
        FAQ: [
            {
                title: "How do we get the recommended course? ",
                text: "The student who participates in answering the Course Directory with Recommendation System will only receive a recommendation after they have previously completed the test, which will display the suggested course based on their performance. Furthermore, the system's results will give students an idea of what subject they have weaknesses in and enhance on it and what possible knowledge and skill set they can significantly improve before enlisting college courses or their suitable interests in their professions.",
            },
            {
                title: "How do we take the exam?",
                text: "Students can find the exam by navigating through the Course Directory with Recommendation System's side navigation bar; there, they can find the specified questions and answers that the recipient was given. There are 25 Science Questions and Answers, 25 Math Questions and Answers, 25 English Questions and Answers, and 25 Reading Comprehension Questions and Answers.",
            },
            {
                title: "Can other students see my Results?",
                text: "No, our team ensures that no one can see the student results and scores other than you, who answered the questions, the system administrator, and the teacher or professor in charge of the section.",
            },
            {
                title: "Can I retake the exam if I want to?",
                text: "Yes, and perhaps no. The student may retake the exam if they do not receive the desired score or outcomes. No, because the student can only take the exam in the computer lab of their school facility and under the supervision of the professor or teacher in charge of the unit. In conclusion, if the professor or teacher assigns a specific date for the student to take the exam and the student fails to do so on time or changes their mind about participating, it is up to the professor or teacher to supervise this student or to move this student to the next section that will take the exam next.",
            },
            {
                title: "Will I have to take the recommended course in my college years?",
                text: "It is up to the student to take the recommended course based on the results; the Course Directory with Recommendation System merely provides a recommendation on what corresponds with their examination scores. This will provide Caloocan High School students with a better understanding of what college career or another interest profession they wish to pursue. If the student wants to avoid following the recommendation, they have the freedom to select or pursue the profession of their choice; this system will provide them a glimpse of what they want in their career.",
            },
        ]
    },
    Examination: {
        modalcontent: {
            title: 'Confirmation',
            description: 'Please take a moment to review your answers and ensure that you have provided a response for each question before submitting.Your answers cannot be changed once the form is submitted.',
            size: 'sm'
        },
        instructions: {
            math: {
                part: 'I',
                direction: 'Choose the correct answer by solving each problem and selecting only the best answer from the options provided below.'
            },
            science: {
                part: 'II',
                direction: 'Analyze the given table and sentence before the questions and select the appropriate answer for the questions below.'
            },
            english: {
                part: 'III',
                direction: 'Each sentence is followed by a series of questions. You will evaluate how the passage could be altered to improve the expression of concepts for some questions. Other questions will need you to examine how the piece could be altered to fix flaws in sentence.'
            },
            reading: {
                part: 'IV',
                direction: 'A series of questions follows each sentence or set of texts below. Choose the best response to each question based on what is stated or suggested in the passage after reading each passage or pair.'
            },
        }
    },
    Profile: {
        sidebar: [
            { id: "Account", label: "Account" },
            { id: "Password", label: "Password" },
            // { id: "Examination", label: "Examination" },
            // { id: "Log Out", label: "Log Out" },
        ],
        text: [
            { title: "General Information", text: "Update your account's profile information and email address." },
            { title: "Change Password", text: "New password must have at least 8 characters and contain 1 lowercase letter, 1 uppercase letter, and 1 numeric digit." },
            { title: "Exam", text: "" },
        ],
        account: [
            { id: "firstname", label: "First name" },
            { id: "lastname", label: "Last name" },
            { id: "lrn", label: "LRN", max: "12", disabled: true },
            { id: "section", label: "Section" },
            // { id: "email", label: "Email Address (optional)" },
            { id: "examStatus", label: "Exam Status", disabled: true },

        ],
        password: [
            { id: "current", label: "Current Password", max: "16" },
            { id: "", label: "" },
            { id: "password", label: "New Password", max: "16" },
            { id: "confirm", label: "Confirm Password", max: "16" },
        ]
    },
    Subjects: ['math', 'science', 'english', 'reading'],
    Interest_Fields: [
        { interest: ["Investigative", "Social"], fields: ["Health Science", "Education & Training"] },
        { interest: ["Realistic", "Social"], fields: ["Health Science", "Human Service", "Law & Public Safety"] },
        { interest: ["Realistic", "Enterprising"], fields: ["Arts & Communications", "Hospitality & Tourism"] },
        { interest: ["Investigative", "Realistic"], fields: ["Agriculture", "Health Science", "Information Technology", "Science, Technology, & Math"] },
        { interest: ["Artistic", "Social"], fields: ["Education & Training", "Arts & Communications", "Marketing & Sales"] },
        { interest: ["Artistic", "Realistic"], fields: ["Arts & Communications", "Education & Training"] },
        { interest: ["Social", "Enterprising"], fields: ["Government", "Law & Public Safety", "Marketing & Sales"] },
        { interest: ["Enterprising", "Conventional"], fields: ["Business & Management", "Finance"] },
        { interest: ["Enterprising", "Artistic"], fields: ["Arts & Communications", "Marketing & Sales", "Architecture & Construction"] },
        { interest: ["Conventional", "Realistic"], fields: ["Architecture & Construction", "Manufacturing", "Transportation"] },
    ],

    SignUp: {
        fields: [],
        dataform: {
            "firstname": "",
            "lastname": "",
            "lrn": "",
            "section": "",
        }
    }
}

