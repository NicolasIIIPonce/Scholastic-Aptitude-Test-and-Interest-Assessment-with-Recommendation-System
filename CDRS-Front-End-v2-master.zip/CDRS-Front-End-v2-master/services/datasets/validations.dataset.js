export default {
    // User Information
    _id: {},
    lrn: {
        regexp: /^[0-9\b]+$/,
        minLength: 12,
        maxLength: 12,
        label: "Please enter number only."
    },
    firstname: {
        regexp: /^[a-z A-Z \b]+$/,
        minLength: 2,
        maxLength: 32,
        label: "Please enter letter only."
    },
    lastname: {
        regexp: /^[a-z A-Z \b]+$/,
        minLength: 2,
        maxLength: 32,
        label: "Please enter letter only."
    },
    password: {
        regexp: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/,
        minLength: 8,
        maxLength: 16,
        label: "Please match the format"
    },
    confirm: {
        maxLength: 16,
    },
    examStatus: {},
    accountStatus: {},
    section: {
        regexp: /^(?!^[0-9- /_]*$)[A-Za-z0-9_/ -]+$/,
        minLength: 2,
        maxLength: 16,
    },
    createdAt: {},
    updatedAt: {},

    //Course Information
    field: {
        minLength: 2,
    },
    acronym: {
        regexp: /^[a-z A-Z \b]+$/,
        minLength: 2,
        maxLength: 40,
    },
    courseName: {
        regexp: /^[a-z A-Z \b]+$/,
        minLength: 15,
        maxLength: 90,
    },
    description: {
        minLength: 5,
        maxLength: 500,
    },
    headerPicture: {
        pattern: 'jpg'
    },
    interest: {},

    courseJob: {
        minLength: 2,
        maxLength: 40,
    },

    math: {
        minLength: 1,
        maxLength: 2,
        regexp: /^[0-9\b]+$/,
    },
    english: {
        minLength: 1,
        maxLength: 2,
        regexp: /^[0-9\b]+$/,
    },
    science: {
        minLength: 1,
        maxLength: 2,
        regexp: /^[0-9\b]+$/,
    },
    readingComprehension: {
        minLength: 1,
        maxLength: 2,
        regexp: /^[0-9\b]+$/,
    },

    CoursePercentage: {
        minLength: 2,
    },

    //Examination
    accessCode: {
        minLength: 4,
        maxLength: 12,
    },
    minute: {},
    startDate: {},
    endDate: {},
    status: {},

    //Subjects
    question: {
        minLength: 2,
        maxLength: 240,
    },
    choiceA: {
        minLength: 1,
        maxLength: 60,
    },
    choiceB: {
        minLength: 1,
        maxLength: 60,
    },
    choiceC: {
        minLength: 1,
        maxLength: 60,
    },
    choiceD: {
        minLength: 1,
        maxLength: 60,
    },
    answer: {
        minLength: 1,
        maxLength: 60,
    },

    //IA Question
    hip: {},
}