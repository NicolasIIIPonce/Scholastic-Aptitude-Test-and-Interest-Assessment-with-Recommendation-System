import axios from "axios"

const apiLink = "https://cdrs-back-end-api.onrender.com/"

export async function ResultGet () {   
    return await axios.get(`${apiLink}result`).then((response) => response.data)
}

export async function ResultSearch (lrn) {  
    return await axios.get(`${apiLink}result/${lrn}`).then((response) => response.data)
}

export async function ResultAdd (result) {  
    return await axios.post(`${apiLink}result/add`, result).then((response) => response.data)
}

export async function SATUpdate (result) {  
    return await axios.post(`${apiLink}result/sat/update/${result.lrn}`, result).then((response) => response.data)
}

export async function SATtotalUpdate (lrn, satresult, sum) {  
    return await axios.post(`${apiLink}result/sat/result/update/${lrn}`, {result : satresult, total: sum}).then((response) => response.data)
}

export async function IAUpdate (lrn, iaresult, result) {  
    return await axios.post(`${apiLink}result/ia/update/${lrn}`, {result: iaresult, algorith: result}).then((response) => response.data)
}

export async function OverallUpdate (lrn, overall) {  
    // console.log(result)
    return await axios.post(`${apiLink}result/all/update/${lrn}`, {result : overall}).then((response) => response.data)
}

