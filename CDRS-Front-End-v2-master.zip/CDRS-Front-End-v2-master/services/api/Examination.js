import axios from "axios"

const apiLink = "https://cdrs-back-end-api.onrender.com/"

export async function ExaminationGet () { 
    return await axios.get(`${apiLink}Examination`).then((response) => response.data)
}

export async function ExaminationSearch (section) {  
    return await axios.get(`${apiLink}Examination/section/${section}`).then((response) => response.data)
}