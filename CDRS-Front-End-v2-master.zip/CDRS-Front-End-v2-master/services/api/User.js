import axios from "axios"

const apiLink = "https://cdrs-back-end-api.onrender.com/"

export async function UserFetch(lrn) {
    return await axios.get(`${apiLink}StudentInformation/lrn/${lrn}`).then((response) => response.data)
}

export async function UserChecking(lrn, password) {
    return await axios.get(`${apiLink}StudentInformation/search/${lrn}&${password}`).then((response) => response.data)
}

export async function UpdateUserPassword(lrn, password) {
    return await axios.post(`${apiLink}StudentInformation/update/lrn/${lrn}&${password}`).then((response) => response.data)
}

export async function UserUpdate(id) {
    return await axios.post(`${apiLink}StudentInformation/update/${id}`).then((response) => response.data)
}

export async function ExamStatusUpdate(lrn) {
    return await axios.post(`${apiLink}StudentInformation/examstatus/update/${lrn}`).then((response) => response.data)
}

export async function UserDelete(id) {
    return await axios.delete(`${apiLink}StudentInformation/${id}`).then((response) => response.data)
}

export async function UserSearchAll(dataform) {
    return await axios.post(`${apiLink}StudentInformation/searchAll/${dataform.lrn}`, 
    { "firstname":dataform.firstname, "lastname": dataform.lastname, "section": dataform.section }
    ).then((response) => response.data)
}