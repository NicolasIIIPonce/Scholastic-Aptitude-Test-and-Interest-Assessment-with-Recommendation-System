import axios from "axios"

const apiLink = "https://cdrs-back-end-api.onrender.com/"

export async function ExamGet (subject) {     //Get the all data
    return await axios.get(`${apiLink}${subject}`).then((response) => response.data)
}