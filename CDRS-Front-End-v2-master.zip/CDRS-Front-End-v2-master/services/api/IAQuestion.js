import axios from "axios"

const apiLink = "https://cdrs-back-end-api.onrender.com/"

export async function IAGet () {     //Get the all data
    return await axios.get(`${apiLink}iAQuestion`).then((response) => response.data)
}