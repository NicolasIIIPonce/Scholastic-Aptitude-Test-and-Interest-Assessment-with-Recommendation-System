import axios from "axios"

const apiLink = "https://cdrs-back-end-api.onrender.com/"

export async function CourseGet () {     //Get the all data
    return await axios.get(`${apiLink}CourseInformation`).then((response) => response.data)
}

export async function CourseGetField (department) {     //Get the all data from a field
    return await axios.get(`${apiLink}CourseInformation/field/${department}`).then((response) => response.data)
}

export async function CourseSearch (courseName) {     //Get a specific course
    return await axios.get(`${apiLink}CourseInformation/${courseName}`).then((response) => response.data)
}

export async function CourseId (id) {     //Get a specific course
    return await axios.get(`${apiLink}CourseInformation/${id}`).then((response) => response.data)
}