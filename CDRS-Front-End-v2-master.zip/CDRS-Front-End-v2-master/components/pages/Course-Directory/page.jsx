import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ref, getDownloadURL } from "firebase/storage";
import { storage } from "../../../services/functions/firebase";

import Dataset from '../../../services/datasets/admin.dataset'
import { CourseGet, CourseGetField } from '../../../services/api/CourseInformation'
import { changeUrl } from '../../../services/functions/global_function'

import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import { Fade } from "@mui/material";


import './style.css'

const CourseDirectory = () => {
    const department = Dataset.CourseInformation.lists.field

    const [Dataform, setDataform] = useState([])

    const [dep, setdep] = useState('')

    const handleChange = (event) => {
        const value = event.target.value
        setdep(value)
        setDataform([])
    }

    const [image, setimage] = useState([])

    const getImage = (id, src) => {

        getDownloadURL(ref(storage, `images/${src}.jpg`)).then((url) => {
            setimage(prev => ({ ...prev, [id]: url }))
        })
            .catch((error) => {
                console.log(`Error: ${error}`)
            });
    }

    useEffect(() => {
        async function FetchCourse() {
            const res = dep === '' ? await CourseGet() : await CourseGetField(dep)
            setDataform(res)
            MapImage(res)
        }

        FetchCourse()

    }, [dep])

    const MapImage = (courses) => {
        courses.map(course => {
            getImage(course.acronym, course.headerPicture)
        })
    }

    return (
        <Fade in={true} timeout={800}>
            <div className="Course_Directory" >
                <div>
                    <div className="Course_D_Header">
                        <p className="Course_p1">Course Directory</p>
                        <div style={{ display: 'flex', gap: '20px' }}>
                            {/* <input className="Course_input" placeholder="Course Name" /> */}
                            <Select
                                value={dep}
                                onChange={handleChange}
                                displayEmpty
                                size="small"
                                sx={{ width: '250px' }}
                            >
                                <MenuItem value="">
                                    <em>All Fields</em>
                                </MenuItem>
                                {
                                    department.map((dep, index) => (
                                        <MenuItem value={dep} key={index}>{dep}</MenuItem>
                                    ))
                                }
                            </Select>
                        </div>
                    </div>
                    <div className="Course_D_Container">
                        {
                            Dataform.map((val, index) => {
                                const { courseName, acronym, field, _id} = val
                                return (
                                    <Link to={`${_id}`} style={{ textDecoration: 'none' }} key={index}>
                                        <div className="Course_D_Box">
                                            <img
                                                src={image[acronym]}
                                                className="Course_B_Img"
                                                id="image"
                                            />
                                            <div className="Course_B_div">
                                                <p className="Course_B_p1">{field}</p>

                                                <p className="Course_B_p2">{courseName}</p>
                                            </div>
                                        </div>
                                    </Link>
                                )
                            })
                        }
                    </div>
                </div>
            </div>
        </Fade>
    )
}

export default CourseDirectory
