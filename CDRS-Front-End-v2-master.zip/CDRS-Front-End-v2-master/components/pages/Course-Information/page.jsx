
import React, { useEffect } from "react";
import { ref, getDownloadURL } from "firebase/storage";
import { storage } from "../../../services/functions/firebase";

import { CourseSearch } from '../../../services/api/CourseInformation'
import { getUrl } from '../../../services/functions/global_function'
import { Grow } from "@mui/material";

import "./style.css"


const CourseInformation = () => {

    const [coursedata, setcoursedata] = React.useState(null)
    const [coursejob, setcoursejob] = React.useState([])
    const [image, setimage] = React.useState()

    useEffect(() => {
        async function FetchCourse() {
            const res = await CourseSearch(getUrl(1))
            setcoursedata(res)
            getImage(res.headerPicture)
        }

        FetchCourse()
        // console.log(getUrl(1))
    }, [])

    const getImage = (src) => {

        getDownloadURL(ref(storage, `images/${src}.jpg`)).then((url) => {
            setimage(url)
        })
            .catch((error) => {
                console.log(`Error: ${error}`)
            });
    }

    // console.log(coursedata)

    const empty = coursedata === null

    return (
        <Grow in={true} timeout={1000}>
            <div className="Course_Info">
                <div className="Course_Info_header">
                    <div>
                        <img src={image} className="Course_header_img"></img>
                    </div>
                    <div>
                        <p className="Course_header_p1">{!empty && coursedata.field}</p>
                        <p className="Course_header_p2">{!empty && coursedata.courseName} ({!empty && coursedata.acronym})</p>
                        <p className="Course_header_p3">{!empty && coursedata.description}</p>
                    </div>
                </div>
                <div className="Course_Info_career">
                    <p className="Course_I_p1">Top 3 best job for {!empty && coursedata.acronym} graduate</p>
                    <div className="Course_Info_c_div">
                        {!empty &&
                            coursedata.courseJob.map((val, index) => {
                                const { jobName, description } = val
                                return (
                                    <div key={index} className="Course_Info_c_box">
                                        <p className="Course_I_c_p1">{jobName}</p>
                                        <p>{description}</p>
                                    </div>
                                )
                            })
                        }
                    </div>
                </div>
            </div>
        </Grow>
    )
}

export default CourseInformation 