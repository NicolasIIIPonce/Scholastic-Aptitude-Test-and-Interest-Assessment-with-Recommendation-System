import * as React from 'react';
import { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";

import Modal from '../../../components/component/Modal/page';

import Dataset from '../../../services/datasets/global.dataset';
import { ExamGet } from '../../../services/api/ExamQuestion';
import { getUrl, clearSession } from '../../../services/functions/global_function';
import { SATUpdate, SATtotalUpdate, OverallUpdate, ResultSearch } from '../../../services/api/Results';
import { SATAlgorithm } from '../../../services/functions/algorithms'

import { Radio, Grid, Zoom } from '@mui/material';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import LinearProgress from '@mui/material/LinearProgress';

import './style.css'

const Radiogroup = {
  '& .MuiSvgIcon-root': {
    fontSize: 20,
  },
}

const SATExam = () => {

  const navigate = useNavigate()
  const { modalcontent, instructions } = Dataset.Examination

  const [answer, setanswer] = useState([])

  const examanswer = JSON.parse(window.sessionStorage.getItem(getUrl(2)))
  const userlrn = JSON.parse(sessionStorage.getItem('userlrn'))
  const time = JSON.parse(sessionStorage.getItem('time'))

  const mn = JSON.parse(sessionStorage.getItem("minute"))
  const sc = JSON.parse(sessionStorage.getItem("second"))

  const [minute, setminute] = useState(mn == null ? 0 : mn)
  const [second, setsecond] = useState(sc == null ? 0 : sc)

  const [examination, setexamination] = useState([])
  const [open, setOpen] = useState(false);
  const [timeout, settimeout] = useState(false)
  const [no, setno] = useState()
  const subject = getUrl(2)

  useEffect(() => {

    async function FetchQuestion() {
      const exam = await ExamGet(`${subject}Question`)
      const ee = exam.map(value => ({ value, sort: Math.random() }))
        .sort((a, b) => a.sort - b.sort).slice(0,25)
        .map(({ value }) => value)

      setexamination(ee)
      SaveAnswer(ee)
    }

    FetchQuestion()

    setno(Number(getUrl(1)) - 1)
  }, [])

  const SaveAnswer = (exam) => {

    if (examanswer === null) {
      const newstate = exam.map((data) => {
        return { id: data._id, keyanswer: data.answer, answer: '' }
      })

      setanswer(newstate)

      sessionStorage.setItem(subject, JSON.stringify(newstate))
    } else {
      setanswer(examanswer)
    }
  }

  const stime = 0

  useEffect(() => {
    if (minute != -1) {
      if (minute === Number(time) && second === Number(stime)) {
        setOpen(true)
        settimeout(true)
      }
      else if (minute <= Number(time)) {
        setTimeout(() => {
          if (second >= 59) {
            setminute(minute + 1)
            setsecond(0)
          } else {
            setsecond(second + 1)
          }
        }, 1000);
      }
      sessionStorage.setItem("minute", JSON.stringify(minute))
      sessionStorage.setItem("second", JSON.stringify(second))
    }
  }, [second]);

  const handleClick = (id, ans) => () => {
    const newState = answer.map(value => {
      if (value.id === id) {
        return { ...value, answer: ans }
      }
      return value
    })

    setanswer(newState)

    sessionStorage.setItem(subject, JSON.stringify(newState))
  }

  const Next = () => {
    if (Number(getUrl(1)) === 25) {
      setOpen(true)
    } else {
      setno(prev => prev + 1)
      navigate(`../${subject}/${no + 2}`)
    }
  }

  const Prev = () => {
    setno(prev => prev - 1)
    navigate(`../${subject}/${no}`)
  }

  const Tab = (i) => () => {
    setno(i - 1)
    navigate(`../${subject}/${i}`)
  }

  const Onsubmit = async() => {
    setOpen(false)

    await UpdateResult()

    const sub = subject === "math" ? 'science' :
      subject === "science" ? 'english' :
        subject === "english" ? 'reading' :
          subject === "reading" ? 'IA-Exam' : 'math';

    sessionStorage.removeItem("minute")
    sessionStorage.removeItem("second")

    if (sub === 'IA-Exam') {
      clearSession()

      navigate(`../../${sub}/1`)
    } else {
      navigate(`../${sub}/1`)
      location.reload()
      // setreload(prev=> prev + 1)
    }
  }

  async function UpdateResult() {
    const score = examanswer.filter((value) => {
      return value.keyanswer === value.answer
    })

    const result = {
      "lrn": Number(userlrn),
      "subject": subject,
      "score": Number(score.length),
      "minute": minute,
      "second": second,
    }

    const res = await SATUpdate(result)

    const resultSearch = await ResultSearch(userlrn)


    const algo = SATAlgorithm(resultSearch, time)
    const otherres = await OverallUpdate(userlrn, algo)

    const resultsat = algo.sort((a, b) => b.efficiency - a.efficiency)
    const satresultupdate = await SATtotalUpdate(userlrn, resultsat[0].subject, totalScore(resultSearch))
  }


  function totalScore(response) {
    let total = 0
    const data = response[0].satExamResult.score
    data.map(data => total += data.score)

    return total
  }

  const exam = examination.length !== 0 ? examination[no] : '';
  const empty = subject === ''
  // const answerkey = answer.length !== 0 ? answer[no].answer: '';
  const uppercase = subject === 'reading' ? 'Reading Comprehension' : subject[0].toUpperCase() + subject.slice(1)
  const answerkey = answer.filter(ans => ans.id == examination[no]._id)
  const useranswer = answerkey.length !== 0 ? answerkey[0].answer : ''

  const GetNumber = (subject) => {
    let sub = JSON.parse(window.sessionStorage.getItem(subject))
    sub = sub === null ? [] : sub
    const number = sub.filter((value) => {
      return value.answer !== ''
    })

    return number.length
  }

  return (
    <Zoom in={true} timeout={1000}>
      <div className="SAT">
        <Grid container spacing={5}>
          <Grid item xs={12} md={8}>
            <div className='SAT-header'>
              <h1>Scholastic Aptitude Test</h1>
              <p><b>Part {!empty && instructions[subject].part} - {uppercase}</b></p>
              <p><b>Directions: </b>{!empty && instructions[subject].direction}</p>
            </div>
            <div className='SAT-box'>
              <h1>Question No. {no + 1}</h1>
              <div style={{ margin: '30px 40px' }}>
                <p className='SAT-box-question'>{exam.question}</p>
                <RadioGroup
                  name={exam._id}
                  sx={Radiogroup}
                >
                  {
                    ['A', 'B', 'C', 'D'].map((value, index) => {
                      const choice = exam[`choice${value}`]
                      const checked = choice == useranswer
                      // console.log(checked)

                      return (
                        <div key={index}>
                          <FormControlLabel
                            sx={{
                              '&:hover': {
                                backgroundColor: 'rgba(69, 141, 107, 0.04)'
                              },
                              borderRadius: '5px',
                              transition: '0.3s',
                              padding: '8px 5px',
                              border: checked ? '1px solid rgb(61, 148, 108,0.4)' : '1px solid rgb(61, 148, 108,0.3)',
                              margin: '5px 0px',
                              boxShadow: checked ? 'rgb(61, 148, 108,0.4) 0px 0px 0px 2px' : 'none',
                              width: '100%'
                            }}
                            control={
                              <Radio
                                checked={checked}
                                onClick={handleClick(exam._id, choice)}
                                sx={{
                                  '& .MuiSvgIcon-root': {
                                    fontSize: 19,
                                  },
                                }}
                                color="success"
                              />
                            }
                            label={<div className="SAT-choice"><p>{choice}</p></div>}
                          />
                        </div>
                      )
                    })
                  }
                </RadioGroup>
              </div>
            </div>
            <div className="SAT-button-group">
              <div>
                {no > 0 && <button className="SAT_prev_btn" onClick={Prev}>Previous</button>}
              </div>
              {no === examination.length - 1 ?
                <button onClick={Next} className="SAT_next_btn">Submit</button>
                :
                <button className="SAT_next_btn" onClick={Next}>Next</button>
              }
            </div>
          </Grid>

          <Grid item xs={12} md={4}>
            <div className='SAT-sidebar'>
              <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                <h3>Time Limit:</h3>
                <p style={{ letterSpacing: '1px', fontSize: '16px' }}>{minute <= 9 && '0'}{minute}:{second <= 9 && '0'}{second} - {time}:00</p>
              </div>
              <h3>Question Status:</h3>
              <div className='SAT-sidebar-status'>
                {
                  examination.map((value, index) => {
                    const fill = answer.filter(val => val.id == value._id && val.answer != "")
                    return (
                      <div key={index} className={`SAT-sidebar-round ${fill.length == 1 && 'SAT-fill'}`} onClick={Tab(index + 1)}>{index + 1}</div>
                    )
                  })
                }
              </div>
              <h3>Subjects:</h3>
              <div className='SAT-sidebar-container'>
                {
                  ['math', 'science', 'english', 'reading'].map((value) => {
                    const no = GetNumber(value)
                    return (
                      <div className='SAT-sidebar-box' key={value}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                          <p>{value[0].toUpperCase() + value.slice(1)}</p>
                          <p>{no}/25</p>
                        </div>
                        <LinearProgress variant="determinate" value={no / 25 * 100} color="success" sx={{ borderRadius: '20px', height: '5px' }} />
                      </div>
                    )
                  })
                }
              </div>
            </div>
          </Grid>

          <Modal open={open} submit={Onsubmit} cancel={() => setOpen(false)} instruction={modalcontent} remove={timeout} />
        </Grid>
      </div>
    </Zoom>
  )
}

export default SATExam