
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ResultSearch } from "../../../services/api/Results";
import { CourseGet } from "../../../services/api/CourseInformation";
import { course_recommendation } from "../../../services/functions/algorithms";

import ResultModal from "../../../components/component/Result-Modal/page"

import dataset from '../../../services/datasets/global.dataset'
import { Box, LinearProgress, Zoom } from "@mui/material";

import CircularProgress from '@mui/material/CircularProgress';

import './style.css'

const Result = () => {

  const userlrn = JSON.parse(sessionStorage.getItem("userlrn"))
  const dialog = JSON.parse(sessionStorage.getItem("dialog"))

  const subjects_array = dataset.Subjects
  const interest_fields = dataset.Interest_Fields

  const [Dataresult, setDataresult] = useState([])
  const [Courses, setCourses] = useState([])
  const [open, setOpen] = useState(dialog == null ? false : dialog.open);

  useEffect(() => {
    async function Fetch() {
      const result = await ResultSearch(userlrn)
      setDataresult(result[0])
      const course = await CourseGet()
      setCourses(course)

      sessionStorage.removeItem("dialog")
    }

    Fetch()

  }, [])

  const columns = [
    "Subjects",
    "Time Finish",
    "Efficiency"
  ]

  const sat_result = Dataresult.satExamResult
  const ia_result = Dataresult.iaExamResult
  const overall_result = Dataresult.overallResult
  const empty = Dataresult.length == 0

  const recommendCourse = () => {
    const result = !empty ? ia_result.result.sort().toString() : []
    const ia = !empty ? interest_fields.filter(values => values.interest.sort().toString() == result) : [{fields: []}]

    const subject = !empty ? sat_result.result : ''
  
    const map = ia[0].fields.map((field, index) => {
      const recommendation = course_recommendation(Courses, field, subject)
      const examresult = !empty && sat_result.total >= 50 ? recommendation.length + 1: 4
      return (
        <div key={index}>
          <p className="ul"><b>{field}</b></p>
          <ul>
            {
              recommendation.length != 0 ?
                recommendation.slice(0, examresult).map((course, index) => {
                  return (
                    <Link to={`../../Course-Directory/${course._id}`} key={index} style={{ textDecoration: 'none', color: 'black' }}>
                      <li className="li">{course.courseName}</li>
                    </Link>
                  )
                })
                :
                <p style={{ marginLeft: '10px', color: 'black' }}>Theres no course recommend</p>
            }
          </ul>
        </div>
      )
    })

    return map
  }

  const subject_color = ["#0096c7", "#52b788", "#f13030", "#f4a261"]

  const interest_color = [
    { title: "Realistic", color: "#ff4d6d", bg: "#ff4d6d4b" },
    { title: "Investigative", color: "#fb8500", bg: "#fb85004b" },
    { title: "Artistic", color: "#ffc300", bg: "#ffc3004b" },
    { title: "Social", color: "#52b788", bg: "#52b7884d" },
    { title: "Enterprising", color: "#00b4d8", bg: "#00b4d84d" },
    { title: "Conventional", color: "#858ae3", bg: "#858ae34d" },
  ]

  return (
    <Zoom in={true} timeout={500}>
      <div className="Result">
        <div className="Result-box">
          <p className="Result_p1">OverAll Results</p>
          <div>
            <p className="Result_p2">SAT OverAll Result: </p>
            <div className="Result_Table_Column">
              {
                columns.map((column, index) => {
                  return (
                    <div key={index} className="Result_Table_Title">{column}</div>
                  )
                })
              }
            </div>
            <div>
              {
                subjects_array.map((subject, index) => {
                  const sat = !empty ? sat_result.score[index] : ''
                  const overall = !empty ? overall_result.result[index].efficiency.$numberDecimal : ''

                  return (
                    <div key={index} className="Result_Table_Row">
                      <div className="Result_Table_p1">{subject[0].toUpperCase()}{subject.slice(1)}</div>
                      <div className="Result_Table_p1">{sat.minute <= 9? '0' : ''}{!empty && sat.minute}:{sat.second <= 9? '0' : ''}{!empty && sat.second}</div>
                      <div className="Result_Table_p1">{!empty ? Number(overall).toFixed(2) : 0}</div>
                    </div>
                  )
                })
              }
            </div>
          </div>
          <div>
            <div>
              <p className="Result_p2" style={{ marginTop: '20px' }}> SAT Total Score: </p>
              <p className="Result_Failed">{!empty ? sat_result.total : 0}</p>
            </div>

            <div>
              <p className="Result_p2"> Highest Subject: </p>
              <p className="Result_Failed">{!empty ? `${sat_result.result[0].toUpperCase()}${sat_result.result.slice(1)}` : ''}</p>
            </div>

            <div>
              <p className="Result_p2">Interest Assement Result: </p>
              <p className="Result_Failed">{!empty ? `${ia_result.result[0]} and ${ia_result.result[1]} ` : ''}</p>
            </div>
            <div>
              <p className="Result_p2">Recommeded Course: </p>
              <div>
                {
                  recommendCourse()
                }
              </div>
            </div>
          </div>

        </div>
        <div className="Result-box2">
          <div className="Profile-result-exam">
            <div style={{ padding: "50px" }}>
              <h1 className="result-title">Scholastic Assessment Test</h1>
              <p className="result-p">Result:</p>
              <div className="Profile-subjects">
                {
                  subjects_array.map((subject, index) => {
                    const score = !empty ? sat_result.score[index].score : 0

                    return (
                      <div key={index} className={`sub ${subject}`}>
                        <h1>{subject}</h1>

                        <Box sx={{ position: 'relative' }}>
                          <CircularProgress
                            variant="determinate"
                            sx={{
                              color: "#e9ecef",
                            }}
                            size={90}
                            thickness={3}
                            value={100}
                          />
                          <CircularProgress
                            variant="determinate"

                            sx={{
                              color: `${subject_color[index]}`,
                              position: "absolute",
                              left: 0
                            }}
                            size={90}
                            thickness={3}
                            value={score / 25 * 100}
                          />
                        </Box>
                        <div className="sub_score_box">
                          <p className="sub_score">{score}</p>
                          <p className="sub_score_txt">Score</p>
                        </div>
                      </div>
                    )
                  })
                }
              </div>
            </div>
          </div>
          <div className="Profile-result-ia">
            <div style={{ padding: "50px" }}>
              <h1 className="result-title">Interest Assessment</h1>
              <p className="result-p">Result:</p>
              <div className="Profile-interest">
                {
                  interest_color.map((interest, index) => {
                    const score = !empty ? ia_result.score[index].score : 0
                    return (
                      <div key={index} className="interest-div">
                        <h1>{interest.title}</h1>
                        <Box sx={{ width: '100%' }}>
                          <LinearProgress
                            sx={{
                              backgroundColor: `${interest.bg}`,
                              '& .MuiLinearProgress-bar': {
                                backgroundColor: `${interest.color}`
                              }
                            }}
                            variant="determinate"
                            value={score / 7 * 100}
                          />
                        </Box>
                        <p>{score}</p>
                      </div>
                    )
                  })
                }
              </div>
            </div>
          </div>
        </div>
        <ResultModal open={open} close={() => setOpen(false)} />
      </div>
    </Zoom>
  )
}

export default Result

{/* <div>
              <p className="Result_p2">Exam Result: </p>
              <p className="Result_Failed">{examresult}</p>
            </div> */}
