
import { useState } from 'react';
import Data from '../../../services/datasets/global.dataset'

import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import { ListItemButton, Collapse } from "@mui/material";

import "./style.css"

const Help = () => {

  const { FAQ } = Data.HelpTab

  const [expanded, setExpanded] = useState(-1);

  const handleChange = (i) => () => {
    setExpanded(expanded === i ? -1 : i);
  }

  return (
    <div className="Help">
      <div className="FAQ-container">
        <div className="FAQ-box">
          <div className="FAQ-header">
            <p className="FAQ-top-text">FAQs</p>
            <p className="FAQ-title">Frequently Asked Questions</p>
            <p className="FAQ-text">Everything you need to know about the system and how it works.</p>
          </div>
          <div className="FAQ-accordion">
            {
              FAQ.map((data, index) => {
                const { title, text } = data
                let expand = expanded === index

                return (
                  <div key={index}>
                    <ListItemButton
                      sx={{
                        display: 'flex',
                        alignContent: 'center',
                        justifyContent: 'space-between',
                        '&:hover': {
                          backgroundColor: 'inherit'
                        },
                        padding: '15px 0px',
                        borderTop: index === 0 ? 'none' : '1px solid #e6e8eb',
                        borderBottom: index === 4 && expanded !== index ? '1px solid #e6e8eb' : 'none'
                      }}
                      onClick={handleChange(index)}
                    >
                      <p className="FAQ-accordion-title"> {title}</p>
                      {expand ? <RemoveIcon /> : <AddIcon />}
                    </ListItemButton>
                    <Collapse
                      in={expand}
                      sx={{
                        paddingRight: '10px',
                        borderBottom: index === 4 ? '1px solid #e6e8eb' : 'none'
                      }}>
                      <p className="FAQ-accordion-text">{text}</p>
                    </Collapse>
                  </div>
                )
              })
            }
          </div>
        </div>
      </div>
    </div>
  )
}

export default Help