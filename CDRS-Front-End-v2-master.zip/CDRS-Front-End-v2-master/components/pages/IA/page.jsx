import React from "react";
import { useEffect, useState } from 'react'
import { useNavigate } from "react-router-dom";

import { IAGet } from '../../../services/api/IAQuestion'
import { getUrl } from '../../../services/functions/global_function';
import { IAUpdate } from "../../../services/api/Results";
import { IAAlgorithm } from "../../../services/functions/algorithms";
import { ExamStatusUpdate } from "../../../services/api/User";

import LinearProgress from '@mui/material/LinearProgress';
import ThumbDownOffAltRoundedIcon from '@mui/icons-material/ThumbDownOffAltRounded';

import './style.css'
import { Grow } from "@mui/material";

const IAExam = () => {

    const navigate = useNavigate()
    const [iaquestion, setiaquestion] = useState([])
    const no = getUrl(1)

    const userlrn = window.sessionStorage.getItem('userlrn')
    const [iascore, setiascore] = useState()
    const result = JSON.parse(sessionStorage.getItem("IAResult"))

    useEffect(() => {
        async function FetchQuestion() {
            const ia = await IAGet()
            setiaquestion(ia)
        }

        FetchQuestion()

        if (result != null) {
            setiascore(result)
        } else {
            setiascore(
                [
                    { hip: 'Realistic', score: 0, },
                    { hip: 'Investigative', score: 0, },
                    { hip: 'Artistic', score: 0, },
                    { hip: 'Social', score: 0, },
                    { hip: 'Enterprising', score: 0, },
                    { hip: 'Conventional', score: 0, },
                ]
            )
        }

    }, [])

    SaveResult()

    function SaveResult() {
        if (iascore != null) {
            sessionStorage.setItem("IAResult", JSON.stringify(iascore))
        }
    }

    const Next = (name) => async () => {

        const newState = iascore.map(prev => {
            if (prev.hip == name) {
                return { ...prev, score: prev.score + 1 }
            }
            return prev
        })

        setiascore(newState)

        if (Number(no) == 42) {
            await UpdateIAResult(IAAlgorithm(newState))
            sessionStorage.setItem("dialog", JSON.stringify({ open: true }))
            sessionStorage.removeItem("IAResult")
            navigate(`../../ExamResult`)
            location.reload()
        } else {
            navigate(`../${Number(no) + 1}`)
        }
    }

    async function UpdateIAResult(algorithm) {
        const res = await IAUpdate(userlrn, result, algorithm)
        const res2 = await ExamStatusUpdate(userlrn)

    }

    const empty = iaquestion.length === 0

    return (
        <Grow in={true} timeout={1000}>
            <div className="IA">
                <p className="IA_p1">Interest Assessment </p>
                <p className="IA_p2">Directions: For the following exam please answer the exam as honestly as you can be because this will
                    be the bearing of the recommended results that you would get. For each of the following statements, choose a one statement that describe or you are interest into.</p>
                <div style={{ width: '100%' }}>
                    <LinearProgress color="success" value={no / (!empty && iaquestion.length) * 100} variant="determinate"
                        sx={{
                            height: '10px',
                            borderTopLeftRadius: '10px',
                            borderTopRightRadius: '10px'
                        }} />
                </div>
                <div className="IA_questions">
                    <div className="IA_div0">
                        <p className="IA_q_p1">Question {no} of {!empty && iaquestion.length}</p>
                        <p className="IA_q_p2">I like to {!empty ? iaquestion[no - 1].question : ''}</p>
                    </div>
                    <div className="IA_div">
                        <button className="IA_button1" onClick={Next(!empty ? iaquestion[no - 1].hip : '')}>
                            <ThumbDownOffAltRoundedIcon
                                sx={{
                                    transform: 'rotate(180deg)',
                                    fontSize: '40px'
                                }} />
                            <p>YES</p>
                        </button>
                        <button className="IA_button2" onClick={Next()} value={""}>
                            <ThumbDownOffAltRoundedIcon
                                sx={{
                                    fontSize: '40px'
                                }} />
                            <p>NO</p>
                        </button>
                    </div>
                </div>
            </div>
        </Grow>
    )
}

export default IAExam