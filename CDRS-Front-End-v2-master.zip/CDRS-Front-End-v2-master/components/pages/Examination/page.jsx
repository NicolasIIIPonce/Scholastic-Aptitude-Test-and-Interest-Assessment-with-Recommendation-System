import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom"

import Modal from "../../component/Modal/page";
import Snackbar from "../../component/Snackbar/page"
import { ResultAdd, ResultSearch } from "../../../services/api/Results";
import { ExaminationSearch, ExaminationGet } from "../../../services/api/Examination";
import { UserFetch } from "../../../services/api/User";

import exam from "../../../src/image/Exams-image.svg"

import './style.css'

const Examination = () => {

  const navigate = useNavigate()

  const userlrn = JSON.parse(sessionStorage.getItem("userlrn"))
  const [openSnackbar, setopenSnackbar] = useState(false);
  const [open, setOpen] = useState(false)
  const [view, setview] = useState(false)

  const result = {
    "lrn": Number(userlrn),
    "satExamResult": {
      "score": [
        { "subject": "math", "score": 0, "minute": 0, "second": 0 },
        { "subject": "science", "score": 0, "minute": 0, "second": 0 },
        { "subject": "english", "score": 0, "minute": 0, "second": 0 },
        { "subject": "reading", "score": 0, "minute": 0, "second": 0 }
      ],
      "total": 0,
      "result": ""
    }
    ,
    "iaExamResult": {
      "score": [
        { "hip": "Realistic", "score": 0 },
        { "hip": "Investigative", "score": 0 },
        { "hip": "Artistic", "score": 0 },
        { "hip": "Social", "score": 0 },
        { "hip": "Enterprising", "score": 0 },
        { "hip": "Conventional", "score": 0 },
      ],
      "result": ""
    },
    "overallResult": {
      "result": [
        { "subject": "math", "accuracy": 0, "average": 0, "efficiency": 0 },
        { "subject": "science", "accuracy": 0, "average": 0, "efficiency": 0 },
        { "subject": "english", "accuracy": 0, "average": 0, "efficiency": 0 },
        { "subject": "reading", "accuracy": 0, "average": 0, "efficiency": 0 }
      ],
      "courseRecommended": "",
    }
  }

  const handleClick = () => {
    setOpen(prev => !prev)
  }

  async function Onsubmit(access) {
    let subject = 'math'
    const userres = await UserFetch(userlrn)
    const exam = await ExaminationSearch(userres.section)

    if (exam.length !== 0 && userres.examStatus !== 'Exam Taken') {
      if (access === exam[0].accessCode && exam[0].status != 'Inactive') {
        const res = await ResultSearch(userlrn)
        if (res.length == 0) {
          const response = await ResultAdd(result)
        } else {
          const response = res[0].overallResult.result.filter((value) => value.efficiency.$numberDecimal == 0)

          subject = response.length === 0 ? 'math' : response[0].subject
        }
        setopenSnackbar(false)

        sessionStorage.setItem("time", JSON.stringify(exam[0].minute))

        navigate(`SAT-Exam/${subject}/1`)
      } else {
        setopenSnackbar(true)
      }
    } else {
      setopenSnackbar(true)
    }
  }

  useEffect(() => {
    async function UserChecking() {
      const userres = await UserFetch(userlrn)
  
      setview(userres.examStatus == 'Exam Taken' ? true : false)
    }

    UserChecking()
  }, [])

  const modalcontent = {
    title: 'Enter Access Code',
    description: 'You can access the exam by entering an access code below',
  }

  return (
    <div className="Examination">
      <div className="Examination-div Examination-text">
        <p className="Examination-p1">Scholastic Aptitude Test And Interest Assessment</p>
        <p className="Examination-p2">Please note that the examination has two parts: the Scholastic Aptitude Test (SAT),
          which assesses your capabilities in four subjects, and the Interest Assessment (IA),
          which evaluates your preferences. Be sure to take both parts of the exam seriously
          and to the best of your ability, as they will help provide insight into your strengths
          and interests.</p>
        <p className="Examination-p3">Here are some instructions in taking an online exam:</p>
        <ul>
          <li>Follow the instructions carefully and answer each question to the best of your ability within the allotted time.</li>
          <li>Check your answers before submitting your exam to ensure that you have answered all questions and that your responses are accurate.</li>
          <li>If you encounter any technical issues during the exam, inform the exam administrator immediately for assistance.</li>
        </ul>
        <div>
          {
            view ?
              <button className="Examination-btn" onClick={() => navigate('examResult')}>View Exam</button>
              :
              <button className="Examination-btn" onClick={handleClick}>Take Exam</button>
          }
        </div>
      </div>
      <div className="Examination-div" style={{ justifyContent: 'center' }}>
        <img src={exam} className="Examination-image"></img>
      </div>
      <Modal open={open} submit={Onsubmit} cancel={() => setOpen(false)} instruction={modalcontent} input={true} />
      <Snackbar open={openSnackbar} method={() => setopenSnackbar(false)} text="Access Denied" vertical="top" horizontal="center" color="error" />
    </div>
  )
}

export default Examination
