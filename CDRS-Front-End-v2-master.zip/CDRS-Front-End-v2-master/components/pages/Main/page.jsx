import { Link } from "react-router-dom";

import Image from "../../../src/image/SignInIcon.svg"
import Data from '../../../services/datasets/global.dataset'

import { Grow, Button } from "@mui/material"
import ProfileIcon from '@mui/icons-material/ManageAccountsOutlined';
import ExamIcon from '@mui/icons-material/NoteAltOutlined';
import FeedOutlinedIcon from '@mui/icons-material/FeedOutlined';
import QuestionMarkOutlinedIcon from '@mui/icons-material/QuestionMarkOutlined';

import './style.css'

const button_sx = {
  fontFamily: "'Lato', sans-serif",
  fontSize: "12px",
  fontWeight: "bold",
  padding: "5px 0px",
}

export default function MainTab() {
  const { Containers } = Data.MainTab

  const icon = [<ProfileIcon />, <ExamIcon />, <FeedOutlinedIcon />, <QuestionMarkOutlinedIcon />]

  return (
    <Grow in={true} timeout={1000}>
      <div className="Main">
        <div className="Main-grid">
          <div className="Main-container mc">
            <img src={Image} className="Main-image" />
            <div className="Main-box">
              <h2>Signed In!</h2>
              <p className="Main-text">Students, welcome to the Caloocan High School Examination Website!</p>
            </div>
          </div>
          {
            Containers.map((item, index) => {
              const { title, text, link, buttontext, iconcolor } = item
              return (
                <div className={`Main-container item m${index + 1}`} key={index}>
                  <div className="Main-icon" style={{ color: iconcolor }}>
                    {icon[index]}
                  </div>
                  <div className="Main-box">
                    <h2>{title}</h2>
                    <p className="Main-text">{text}</p>
                    <Link to={link} style={{ textDecoration: "none" }}>
                      <Button sx={button_sx}>{buttontext}</Button>
                    </Link>
                  </div>
                </div>
              )
            })
          }
        </div>
      </div>
    </Grow>
  )
}
