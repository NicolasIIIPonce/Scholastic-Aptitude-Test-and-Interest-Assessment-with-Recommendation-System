
import Data from '../../../services/datasets/global.dataset'

import { Fade } from "@mui/material";

import './style.css'

const IAInformation = () => {
  const { header, ia, lower, career, colors } = Data.IAInformation

  return (
    <Fade in={true} timeout={1000}>
      <div className="IA-Information">
        <div className="IA-Information-header">
          {
            header.map((val, index) =>
            (
              <div key={val.id}>
                <p className="IA-Information-p1">{val.title}</p>
                <p className="IA-Information-p2">{val.text}</p>
              </div>
            )
            )}
        </div>
        <div style={{ boxShadow: 'rgba(0, 0, 0, 0.09) 0px 3px 12px', margin: '30px 0px' }}>
          {
            ia.map((val, index) => {
              return (
                <div className="IA-Information-table-1" key={val.id} style={{ borderBottom: index === Data.length - 1 ? '1px solid #e9ecef' : '0px' }}>
                  <div className="IA-Information-col-1" >
                    <div className="IA-Information-col-1-p1"><p style={{ color: `rgb(${colors[index]})` }}>{val.label[0]}</p></div>
                    <div className="IA-Information-col-1-p2"><p style={{ color: `rgb(${colors[index]})` }}>{val.label}</p></div>
                  </div>
                  <div>
                    <div className='IA-Information-col-2'>
                      <p className="IA-Information-col-2-p1">{val.title}</p>
                      <p className="IA-Information-col-2-p2"><b>Personality traits: </b>{val.personality}</p>
                      <p className="IA-Information-col-2-p2"><b>Hobbies and career interests: </b> {val.hobies}</p>
                    </div>
                  </div>
                </div>
              )
            })
          }
        </div>
        <div>
          <p className='IA-Information-p1'>{lower.title}</p>
          <p className='IA-Information-p2'>{lower.text}</p>
        </div>
        <div className="IA-Information-table-2">
          {
            career.map((val, index) => (
              <div className="IA-Information-column" key={val.id}>
                <p
                  className="IA-Information-column-title"
                  style={{ backgroundColor: `rgb(${colors[index]}, 0.75)` }}
                >
                  {val.columntitle[0]}-{val.columntitle}
                </p>
                {
                  val.columntext.map((colval, index) => {
                    return (
                      <p className="IA-Information-column-text" key={index}>{colval}</p>
                    )
                  })
                }
              </div>
            ))
          }
        </div>
      </div>
    </Fade>
  )
}

export default IAInformation