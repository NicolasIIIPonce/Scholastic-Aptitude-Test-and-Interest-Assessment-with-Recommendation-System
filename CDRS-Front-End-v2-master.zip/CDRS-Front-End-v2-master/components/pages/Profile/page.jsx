


import { useState, useEffect, useRef } from "react";
import { Link, json } from 'react-router-dom';

import Data from '../../../services/datasets/global.dataset';
import Account from '../../layout/Account/page';
import Password from '../../layout/Password/page';
import { getUrl, getSession} from '../../../services/functions/global_function';
import { UserFetch } from "../../../services/api/User";

import PermIdentityRoundedIcon from '@mui/icons-material/PermIdentityRounded';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import AssignmentOutlinedIcon from '@mui/icons-material/AssignmentOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
import { Zoom } from "@mui/material";

import './style.css'

const Profile = () => {
    const { sidebar, text } = Data.Profile

    const userlrn = getSession("userlrn")

    const datafields = useRef({
        profile: {firstname: '', lastname: '', lrn: '', email: '' , examresult: "", section: ""},
        password : {currentpass: '', password : '', confirmpass: ''}
    })

    const [Dataform, setDataform] = useState(datafields.current.profile)
    const [Passwordform, setPasswordform] = useState(datafields.current.password)

    const icon = [
        <PermIdentityRoundedIcon />,
        <LockOutlinedIcon />,
        <AssignmentOutlinedIcon />,
        <LogoutOutlinedIcon />,
    ];

    const url = sidebar.findIndex((arr) => arr.label === getUrl(1))

    const [tab, settab] = useState(url)

    const onClickTab = (index) => () => {
        settab(index)
        setDataform(datafields.current.profile)
        setPasswordform(datafields.current.password)
    }

    useEffect(()=>{
        async function Fetch(){
            const res = await UserFetch(userlrn)
            setDataform(res)
        }
        Fetch()
    },[])

    return (
        <Zoom in={true} timeout={500}>
            <div className="Profile">
                <div className="Profile-container">
                    <div className="Profile-title-box">
                        <h1>Student Profile</h1>
                        <p>Change your profile and account settings</p>
                    </div>
                    <div className="Profile-box">
                        <div className="Profile-sidebar">
                            {
                                sidebar.map((value, index) => {
                                    const active = index === tab
                                    return (
                                        <Link to={`../${value.label}`} style={{ textDecoration: 'none' }} key={index}>
                                            <button onClick={onClickTab(index)} style={{ color: active && '#388E3C' }}>
                                                {icon[index]}
                                                <span>{value.label}</span>
                                            </button>
                                        </Link>
                                    )
                                })
                            }
                        </div>
                        <div className="Profile-tab">
                            {
                                tab === 0 ? <Account title={text[tab].title} text={text[tab].text} data={Dataform}/> 
                                : <Password title={text[tab].title} text={text[tab].text} data={Dataform.lrn}/>
                            }
                        </div>
                    </div> 
                </div>
            </div>
        </Zoom>
    )
}

export default Profile