import { useState, useEffect } from "react";
import axios from "axios"

import Header from "../Header/page"
import DataTable from "../Table/page"
import Optionbar from "../../component/Optionbar/page"
import Modal from "../../component/Modal/page"
import Snackbar from "../../component/Snackbar/page"

import Datasets from "../../../services/datasets/admin.dataset"
import { getUrl } from "../../../services/functions/global_function"

import { Grow } from "@mui/material";

export default function Content() {

    const exams = ["satExamResult", "iaExamResult", "overallResult"]
    const subjects = ["MathQuestion", "ScienceQuestion", "EnglishQuestion", "ReadingQuestion"]

    const key = exams.includes(getUrl(1))
    const subject = subjects.includes(getUrl(1))

    const data = subject ? "subjects" : getUrl(1)
    const { instructions, fields } = Datasets[data]

    const [Dataform, setDataform] = useState([])
    const [opendialog, setopendialog] = useState(false)
    const [opensnack, setopensnack] = useState(false)
    const [alertmessage, setalertmessage] = useState('')
    const [id, setid] = useState(0)
    const [field, setfield] = useState('All')
    const [search, setsearch] = useState('')
    const method = JSON.parse(sessionStorage.getItem("method"))

    useEffect(() => {
        async function FetchData() {
            const res = await axios.get(`https://cdrs-back-end-api.onrender.com/${key ? getUrl(2) : getUrl(1)}`).then((response) => response.data)

            UpdateDate(res)

            if (getUrl(1) === exams[0]) {
                for (let i = 0; i < res.length; i++) {
                    setDataform(prev => [
                        ...prev,
                        {
                            lrn: res[i].lrn,
                            math: res[i].satExamResult.score[0].score,
                            english: res[i].satExamResult.score[1].score,
                            science: res[i].satExamResult.score[2].score,
                            reading: res[i].satExamResult.score[3].score,
                            total: res[i].satExamResult.total,
                            result: res[i].satExamResult.result,
                        }
                    ])
                }
            } else if (getUrl(1) === exams[1]) {
                for (let i = 0; i < res.length; i++) {
                    setDataform(prev => [
                        ...prev,
                        {
                            lrn: res[i].lrn,
                            Realistic: res[i].iaExamResult.score[0].score,
                            Investigative: res[i].iaExamResult.score[1].score,
                            Artistic: res[i].iaExamResult.score[2].score,
                            Social: res[i].iaExamResult.score[3].score,
                            Enterprising: res[i].iaExamResult.score[4].score,
                            Conventional: res[i].iaExamResult.score[1].score,
                            Result_A: res[i].iaExamResult.result[0],
                            Result_B: res[i].iaExamResult.result[1],
                        }
                    ])
                }
            } else if (getUrl(1) === exams[2]) {
                for (let i = 0; i < res.length; i++) {
                    setDataform(prev => [
                        ...prev,
                        {
                            lrn: res[i].lrn,
                            Math: Number(res[i].overallResult.result[0].efficiency.$numberDecimal).toFixed(2),
                            Science: Number(res[i].overallResult.result[1].efficiency.$numberDecimal).toFixed(2),
                            English: Number(res[i].overallResult.result[2].efficiency.$numberDecimal).toFixed(2),
                            Reading: Number(res[i].overallResult.result[3].efficiency.$numberDecimal).toFixed(2),
                        }
                    ])
                }
            } else {
                setDataform(res)
            }
        }

        function getSession() {
            if (method != null) {
                setopensnack(true)
                setalertmessage(method.text)
                sessionStorage.removeItem("method")
            }
        }
        FetchData()
        getSession()

        function UpdateDate(res) {
            var todayDate = new Date().toISOString().slice(0, 10);
            const newDate = Date.parse(todayDate)


            for (let i = 0; i < res.length; i++) {
                if ((Date.parse(res[i].startDate) <= newDate) && (Date.parse(res[i].endDate) >= newDate)) {
                    axios.post(`https://cdrs-back-end-api.onrender.com/Examination/status/update/${res[i]._id}`, { result: "Active" })
                } else {
                    axios.post(`https://cdrs-back-end-api.onrender.com/Examination/status/update/${res[i]._id}`, { result: "Inactive" })
                }
            }
        }
    }, [])

    const handleClickdelete = (id) => {
        setopendialog(true)
        setid(id)
    };

    function dataperrow(id, data, index) {
        const value = data[id];

        if (id == "action") {
            return (
                <Optionbar id={data._id} handleDelete={handleClickdelete} />
            )
        } else {
            return (
                <p>{value}</p>
            )
        }
    }

    const deletecontent = {
        title: `Delete this Record?`,
        description: `Are you sure you want to delete this record (${id})`,
    }

    const DeleteRecord = async () => {
        await axios.delete(`https://cdrs-back-end-api.onrender.com/${getUrl(1)}/${id}`).then((response) => response.data)
        sessionStorage.setItem("method", JSON.stringify({ text: 'Record was successfully deleted!' }))
        location.reload()
    }

    const changeField = () => (event) => {
        const { value } = event.target
        setfield(value)
        setsearch('')
    }

    const OnchangeSearch = () => (event) => {
        const { value } = event.target
        setsearch(value)
    }
    return (
        <Grow in={true} timeout={600}>
            <div>
                <Header
                    Title={instructions.title || ''}
                    ViewText={instructions.subtext || ''}
                    Function={getUrl(1)}
                    Text={instructions.text || ''}
                    Add={instructions.add || ''}
                    Edit={instructions.edit || ''}
                />
                <DataTable
                    Column={fields}
                    Row={Dataform.filter(data => field=='All'? data : data[field] == search)}
                    Function={dataperrow}
                    Field={field}
                    ChangeField={changeField}
                    OnChange={OnchangeSearch}
                    Text={search}
                />
                <Modal open={opendialog} submit={DeleteRecord} cancel={() => setopendialog(false)} instruction={deletecontent} />
                <Snackbar open={opensnack} method={() => setopensnack(false)} text={alertmessage} color="success" vertical="bottom" horizontal="right" />
            </div>
        </Grow>
    )
}