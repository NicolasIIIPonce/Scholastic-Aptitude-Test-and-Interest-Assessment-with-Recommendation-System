//Dependencies
import { useEffect, useState } from "react"
import { storage } from "../../../services/functions/firebase"
import { ref, uploadBytes } from "firebase/storage"
import { useNavigate } from "react-router-dom"
import axios from "axios"

import Header from "../Header/page"
import ComboBox from "../../component/ComboBox/page"
import File from "../../component/File/page"
import TextArea from "../../component/Textarea/page"
import Textbox from "../../component/Textbox/page"
import ButtonGroup from "../../component/Button-Group/page"
import PasswordField from "../../component/Password-Field/page"
import CoursePercentage from "../Course-Percentage/page"
import JobFields from "../JobFields/page"

import DataSet from "../../../services/datasets/admin.dataset"
import ValidationSet from "../../../services/datasets/validations.dataset"
import { limitation } from "../../../services/functions/validation"
import { getUrl, removeExtension } from "../../../services/functions/global_function"
import { UserFetch } from "../../../services/api/User"
import Fade from "@mui/material/Fade";

import './style.css'


export default function FormsCourseInformation() {
    const navigate = useNavigate()

    const subjects = ["MathQuestion", "ScienceQuestion", "EnglishQuestion", "ReadingQuestion"]
    const url = subjects.includes(getUrl(3)) ? "subjects" : getUrl(3)
    const { forms, instructions, lists, dataform } = DataSet[url]

    var todayDate = new Date().toISOString().slice(0, 10);
    const newDate = Date.parse(todayDate)

    const [Dataform, setDataform] = useState(dataform)
    const [valtext, setvaltext] = useState('')
    const [imageUpload, setImageUpload] = useState(null)

    useEffect(() => {
        if (getUrl(2) == 'Edit') {
            axios.get(`https://cdrs-back-end-api.onrender.com/${getUrl(3)}/${getUrl(1)}`).then(response => {
                setDataform(response.data)
                setImageUpload(response.data.headerPicture)
            })
        }
    }, [])

    function FormInput(form) {
        const { id, title, inputno, disabled, random } = form
        const minLength = ValidationSet[id].minLength != null ? ValidationSet[id].minLength : 3

        switch (inputno) {
            case 1:
                return (
                    <div>
                        <Textbox
                            id={id}
                            title={title}
                            value={Dataform[id]}
                            method={Onchange}
                            disabled={disabled}
                            min={minLength}
                            id1={id}
                        />
                        {
                            (id == "lrn" || id == "answer") &&
                            <p className="Login-Form-validation" style={{ marginTop: '5px' }}>{valtext}</p>
                        }
                    </div>
                )
                break;
            case 2:
                return (
                    <PasswordField
                        id={id}
                        title={title}
                        value={Dataform[id]}
                        method={Onchange}
                        random={random}
                        min={minLength}
                    />
                )
                break;
            case 3:
                return (
                    <TextArea
                        id={id}
                        title={title}
                        value={Dataform[id]}
                        method={Onchange}
                    />
                )
                break;
            case 4:
                return (
                    <ComboBox
                        id={id}
                        value={Dataform[id]}
                        method={Onchange}
                        list={lists[id]}
                    />
                )
                break;
            case 5:
                return <File pattern={ValidationSet[id].pattern} method={Onchange} />
                break;
            case 6:
                return <JobFields jobs={Dataform.courseJob} method={Onchange} />
                break;
            case 7:
                return <CoursePercentage data={Dataform.coursePercentage} method={Onchange} />
                break;
            case 8:
                return (
                    <input
                        name={id}
                        type="date"
                        className="Forms-input"
                        style={{ textIndent: 5, paddingRight: 10 }}
                        value={Dataform[id]}
                        onChange={Onchange}
                        min={todayDate}
                        required
                    />
                )
                break;
            default:
                return 1
        }
    }

    const Onchange = async (event) => {

        const { name, value, type, id, placeholder } = event.target

        const checkLRN = await CheckingDuplicate(value)
        const subjects = ['math', 'science', 'english', 'readingComprehension']
        const answer = [Dataform.choiceA, Dataform.choiceB, Dataform.choiceC, Dataform.choiceD]

        if (name == "headerPicture") {
            setImageUpload(event.target.files[0])
        } else if (name == "randomaccess") {
            const result = Math.random().toString(36).substring(2, 8);
            setDataform(prev => ({ ...prev, "accessCode": result }))
        } else if (name == "startDate") {
            setDataform(prev => ({ ...prev, "status": newDate < Date.parse(value) ? "Inactive" : "Active" }))
        } else if (name == "lrn" && checkLRN != null) {
            setvaltext('LRN already exists')
        } else if (name == "answer" && !answer.includes(value)) {
            setvaltext('Theres no right answer')
        } else if ((name == "answer" && answer.includes(value)) || (name == "lrn" && checkLRN == null)) {
            setvaltext('')
        }

        if ((limitation(name, value) && type == "text" || value == "") || type != "text") {
            if (subjects.includes(name)) {
                setDataform(prev => ({ ...prev, "coursePercentage": { ...prev.coursePercentage, [name]: Number(value) } }))
            }
            else if (name == "courseJob") {
                const newState = Dataform.courseJob.map((data, index) => {
                    if (index == id) {
                        return { ...data, [placeholder]: value }
                    }
                    return data
                })

                setDataform(prev => ({ ...prev, courseJob: newState }))
            }
            else {
                setDataform(prev => ({
                    ...prev,
                    [name]: name == "headerPicture" ? removeExtension(event.target.files[0].name)
                        : value
                }))
            }
        }
    }

    async function CheckingDuplicate(value) {
        if (ValidationSet.lrn.regexp.test(value)) {
            const checkLRN = await UserFetch(Number(value))
            return checkLRN
        }
    }

    const uploadImage = () => {
        if (getUrl(3) == "CourseInformation") {
            const imageRef = ref(storage, `images/${imageUpload.name}`)
            uploadBytes(imageRef, imageUpload).then(() => {
            })
        }
    }

    const Submit = (event) => {
        event.preventDefault();

        let data;
        if (getUrl(2) == 'Add') {
            data = "Record was successfully added"
            axios.post(`https://cdrs-back-end-api.onrender.com/${getUrl(3)}/add`, Dataform).then((response) => response.data)
            uploadImage()
        } else {
            data = "Record was successfully updated"
            axios.post(`https://cdrs-back-end-api.onrender.com/${getUrl(3)}/update/${getUrl(1)}`, Dataform).then((response) => response.data)
            uploadImage()
        }

        sessionStorage.setItem("method", JSON.stringify({ text: data }))
        navigate(`../../${getUrl(3)}`)
    }

    return (
        <Fade in={true} timeout={1000}>
            <div>
                <Header
                    Title={instructions.title}
                    Text={instructions.text}
                    Function={getUrl(1)}
                />
                <form action="" onSubmit={Submit}>
                    <div style={{ margin: '20px 0px' }}>
                        {
                            forms.map((fields, index) => {

                                const { id, title, text } = fields
                                const notinclude = ['_id', 'createdAt', 'updatedAt']

                                return (
                                    (!notinclude.includes(id) && getUrl(2) == 'Add' || getUrl(2) == 'Edit') &&
                                    <div className="Forms-container" key={index} style={{ alignItems: "flex-start" }}>
                                        <div>
                                            <p className="Forms-title">{title}</p>
                                            <p className="Forms-subtitle">{text}</p>
                                        </div>
                                        <div style={{ width: '90%' }}>
                                            {fields.sub != null ?
                                                fields.sub.map((values, index) => {
                                                    FormInput(values)
                                                })
                                                : FormInput(fields)
                                            }
                                        </div>
                                    </div>
                                )
                            })
                        }
                    </div>
                    <ButtonGroup onSubmit={Submit} cancel={() => navigate('..')} url={getUrl(2)} validation={valtext}/>
                </form>
            </div>
        </Fade>
    )
}
