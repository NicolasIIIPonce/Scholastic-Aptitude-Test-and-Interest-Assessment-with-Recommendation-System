import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom'

import logo from '../../../src/icon/logo.png'
import Data from '../../../services/datasets/global.dataset'
import Modal from '../../component/Modal/page';

import { UserFetch } from '../../../services/api/User';

import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import MenuIcon from '@mui/icons-material/Menu';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import { Avatar } from '@mui/material';
import ArrowBackIosRoundedIcon from '@mui/icons-material/ArrowBackIosRounded';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';

import "./style.css"

export default function NewNav(props) {

    const userlrn = JSON.parse(sessionStorage.getItem("userlrn"))

    const drawerWidth = 240;
    const { Dashboard } = Data
    const { tab, handletab } = props

    const navigate = useNavigate()

    const [mobileOpen, setMobileOpen] = useState(false);
    const [opendialog, setopendialog] = useState(false);

    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);

    const handleDrawerToggle = () => {
        setMobileOpen((prevState) => !prevState);
    };

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const [name, setname] = useState()

    useEffect(() => {
        async function Fetch() {
            const res = await UserFetch(userlrn)
            setname(res.firstname + " " + res.lastname)
        }

        Fetch()

    })

    const drawer = (
        <Box onClick={handleDrawerToggle} sx={{ textAlign: 'center' }}>
            <div className='Navbar-logo-container' style={{ padding: '15px 0px' }}>
                <img src={logo} className="Navbar-Logo" />
                <p className='Navbar-title'>CDRS</p>
            </div>
            <Divider />
            <List>
                {
                    Dashboard.Navbar.map((item, index) => {
                        const { link, label } = item
                        let active = link === tab
                        return (
                            <Link
                                to={link}
                                style={{
                                    textDecoration: 'none',
                                }}
                                key={index}
                            >
                                <ListItem disablePadding>
                                    <ListItemButton
                                        sx={{
                                            textAlign: 'center',
                                            color: active ? '#407d61' : '#1a2c2aff',
                                        }}
                                        onClick={() => { handletab(link) }}
                                    >
                                        <ListItemText primary={label} />
                                    </ListItemButton>
                                </ListItem>
                            </Link>
                        )
                    })
                }
            </List>
        </Box>
    )

    const button_sx = (active) => {
        return {
            padding: '8px 15px',
            color: active ? 'white' : '#1a2c2aff',
            backgroundColor: active ? '#458d6b' : 'none',
            transition: active ? '0.5s' : '0.5s',
            '&:hover': {
                backgroundColor: active ? '#407d61' : 'rgb(69, 141, 107,0.09)'
            }
        }
    }

    const buttonExit = () => {
        setopendialog(prev => !prev)
        handleClose()
    }

    const handleLeave = () => {
        sessionStorage.clear()
        navigate('/')
    }

    const content = {
        title: 'Signing Out?',
        description: 'Are you sure you want to Sign Out?',
        size: 'xs'
    }

    return (
        <div>
            <AppBar component="nav" sx={{ backgroundColor: 'white', boxShadow: 'rgba(99, 99, 99, 0.05) 0px 2px 8px 0px;' }} elevation={0}>
                <Toolbar>
                    <div className='Navbar-option'>
                        <IconButton
                            color="inherit"
                            edge="start"
                            onClick={() => setMobileOpen(e => !e)}
                            sx={{ mr: 2, color: '#458d6b' }}
                        >
                            <MenuIcon />
                        </IconButton>
                    </div>

                    <Box sx={{ width: '100%' }}>
                        <div className='Navbar-container'>
                            <div className='Navbar-logo-container'>
                                <img src={logo} className="Navbar-Logo" />
                                <p className='Navbar-title'>CDRS</p>
                            </div>
                            <div className='Navbar-items'>
                                {Dashboard.Navbar.map((item, index) => {
                                    const { label, link } = item

                                    let active = link === tab
                                    return (
                                        <Link
                                            to={link}
                                            style={{
                                                textDecoration: 'none',
                                                display: 'flex',
                                                alignItems: 'center',
                                            }}
                                            key={index}
                                        >
                                            <Button
                                                sx={button_sx(active)}
                                                onClick={() => { handletab(link) }}
                                            >
                                                <p className='Navbar-label'>{label}</p>
                                            </Button>
                                        </Link>
                                    )
                                })}
                            </div>
                            <div className='Navbar-avatar-container'>
                                <button className='Navbar-avatar-button ' onClick={handleClick}>
                                    <Avatar sx={{ backgroundColor: '#d8f3dce6', color: '#458d6b', fontSize: '16px' }}></Avatar>
                                    <div className='Navbar-avatar-info'>
                                        {/* <p className='Navbar_Avatar_p1'> {props.userdata.FIRSTNAME} {props.userdata.LASTNAME}</p> */}
                                        <p className='Navbar-avatar-name'>{name}</p>
                                        <p>Student</p>
                                    </div>
                                    <ArrowBackIosRoundedIcon sx={{ color: '#6f727eff', fontSize: '16px', transform: 'rotate(270deg)' }} />
                                </button>
                                <Menu
                                    id="basic-menu"
                                    anchorEl={anchorEl}
                                    open={open}
                                    onClose={handleClose}
                                    anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                                    transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                                >
                                    <Link to="Profile/Account" style={{ textDecoration: 'none' }}>
                                        <MenuItem onClick={handleClose}>
                                            <p className='Navbar-menu-p1'>Profile</p>
                                        </MenuItem>
                                    </Link>
                                    <MenuItem onClick={buttonExit}>
                                        <p className='Navbar-menu-p1'>Sign Out</p>
                                    </MenuItem>
                                </Menu>
                            </div>
                        </div>
                    </Box>
                </Toolbar>
            </AppBar>

            <Box component="nav">
                <Drawer
                    variant="temporary"
                    open={mobileOpen}
                    onClose={handleDrawerToggle}
                    ModalProps={{
                        keepMounted: true,
                    }}
                    sx={{
                        display: { md: 'block', lg: 'none' },
                        '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
                    }}
                >
                    {drawer}
                </Drawer>
            </Box>

            {opendialog && <Modal open={opendialog} cancel={buttonExit} submit={handleLeave} instruction={content} />}
        </div>
    )
}