import Textbox from "../../component/Textbox/page"
import TextArea from "../../component/Textarea/page"

const page = ({ jobs, method}) => {
    return (
        <div>
            {
                jobs.map((job, index) => {
                    return (
                        <div key={index} style={{margin: '10px 0px', display: 'flex', flexDirection: 'column', gap:'5px'}}>
                            <Textbox
                                id="courseJob"
                                id1={index}
                                title="jobName"
                                value={job.jobName}
                                method={method}
                            />
                            <TextArea
                                id="courseJob"
                                id1={index}
                                title="description"
                                value={job.description}
                                method={method}
                            />
                        </div>
                    )
                })
            }
            {/* <div>
                <Textbox
                    id="1"
                    title="math"
                    value={String(data.math)}
                    method={method}
                />
                <TextArea
                    id="2"
                    title={title}
                    value={Dataform[id]}
                    method={Onchange}
                />
                <Textbox
                    id="science"
                    title="science"
                    value={String(data.science)}
                    method={method}
                />
                <TextArea
                    id={id}
                    title={title}
                    value={Dataform[id]}
                    method={Onchange}
                />
                <Textbox
                    id="english"
                    title="english"
                    value={String(data.english)}
                    method={method}
                />

                <TextArea
                    id={id}
                    title={title}
                    value={Dataform[id]}
                    method={Onchange}
                />

            </div> */}
        </div>
    )
}

export default page
