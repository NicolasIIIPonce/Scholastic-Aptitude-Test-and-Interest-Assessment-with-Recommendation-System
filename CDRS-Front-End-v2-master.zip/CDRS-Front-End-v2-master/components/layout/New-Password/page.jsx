import { useState } from "react"
import { useNavigate } from 'react-router-dom';

import { validation, limitation, confirmpass } from '../../../services/functions/validation'
import { UpdateUserPassword } from '../../../services/api/User'

import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import RemoveRedEyeOutlinedIcon from '@mui/icons-material/RemoveRedEyeOutlined';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
import { Fade } from "@mui/material";

const ChangePasswordBtn = {
    width: "100%",
    height: "40px",
    backgroundColor: "#388E3C",
    color: "white",
    fontSize: "16px",
    fontFamily: "'Poppins', sans-serif",
    border: "0px",
    marginTop: "110px",
    boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px",
    borderRadius: "5px",
    textTransform: "none",
    letterSpacing: "1.5px",

    "&:hover": {
        backgroundColor: "#2e7d32"
    }
}

const NewPassword = ({ lrn }) => {
    const navigate = useNavigate()

    const [Dataform, setDataform] = useState({ password: '', confirm: '' })

    const [showpass, setshowpass] = useState({ password: false, confirm: false })

    const [valText, setvalText] = useState({ password: false, confirm: false })

    const handlechange = (event) => {
        const { name, value } = event.target

        if (limitation(name, value) || value === "") {
            setDataform(prev => ({
                ...prev,
                [name]: value
            }))

            setvalText(prev => ({ ...prev, [name]: value == "" ? 'Please fill in this required fields.' : false }))
        }
    }

    async function CreatePassword() {
        const passvalid = validation('password', Dataform.password, true)
        const confirmvalid = confirmpass(Dataform.password, Dataform.confirm)

        setvalText(prev => ({
            ...prev,
            password: passvalid,
            confirm: confirmvalid,
        }))

        if (passvalid === "success" && confirmvalid === "success") {
            const res = await UpdateUserPassword(lrn, Dataform.password)
            sessionStorage.setItem("change", true)
            navigate("/")
        }
    }


    return (
        <Fade in={true} timeout={1000}>
            <div className="SignUp-Form-box">
                <FormControl className="Login-Form-input" sx={{ margin: '10px 0px 5px' }} variant="outlined" >
                    <InputLabel>
                        <p
                            style={{
                                color: !valText.password ? '#4e7f38ff' :
                                    valText.password === 'success' ? '#4e7f38ff' : 'red'
                            }}
                        >
                            New Password
                        </p>
                    </InputLabel>
                    <OutlinedInput
                        error={!valText.password ? false
                            : valText.password === 'success' ? false : true
                        }
                        name="password"
                        type={showpass.password ? 'text' : 'password'}
                        endAdornment={
                            <InputAdornment position="end">
                                <IconButton
                                    onClick={() => setshowpass(prev => ({ ...prev, password: !showpass.password }))}
                                    edge="end"
                                >
                                    {showpass.password ? <VisibilityOffOutlinedIcon /> : <RemoveRedEyeOutlinedIcon />}
                                </IconButton>
                            </InputAdornment>
                        }
                        label="New Password"
                        color="success"
                        value={Dataform.password}
                        onChange={handlechange}
                    />
                </FormControl>
                {
                    valText.password != 'success' &&
                    <p
                        className="Login-Form-validation"
                        style={{
                            paddingBottom: valText.password ? "2px" : "0px",
                            height: valText.password ? "12px" : "0px"
                        }}
                    >
                        <span>{valText.password}</span>
                    </p>
                }

                <FormControl className="Login-Form-input" sx={{ margin: '10px 0px 5px' }} variant="outlined" >
                    <InputLabel>
                        <p
                            style={{
                                color: !valText.confirm ? '#4e7f38ff' :
                                    valText.confirm === 'success' ? '#4e7f38ff' : 'red'
                            }}
                        >
                            Confirm Password
                        </p>
                    </InputLabel>
                    <OutlinedInput
                        error={!valText.confirm ? false
                            : valText.confirm === 'success' ? false : true
                        }
                        name="confirm"
                        type={showpass.confirm ? 'text' : 'password'}
                        endAdornment={
                            <InputAdornment position="end">
                                <IconButton
                                    onClick={() => setshowpass(prev => ({ ...prev, confirm: !showpass.confirm }))}
                                    edge="end"
                                >
                                    {showpass.confirm ? <VisibilityOffOutlinedIcon /> : <RemoveRedEyeOutlinedIcon />}
                                </IconButton>
                            </InputAdornment>
                        }
                        label="Confirm Password"
                        color="success"
                        value={Dataform.confirm}
                        onChange={handlechange}
                    />
                </FormControl>

                {
                    valText.confirm != 'success' &&
                    <p
                        className="Login-Form-validation"
                        style={{
                            paddingBottom: valText.confirm ? "2px" : "0px",
                            height: valText.confirm ? "12px" : "0px"
                        }}
                    >
                        <span>{valText.confirm}</span>
                    </p>
                }

                <Button variant="contained" onClick={CreatePassword} sx={ChangePasswordBtn} >Create Password</Button>
                <button className='Sign-Up-back-btn' onClick={() => location.reload()}>Go Back</button>
            </div>
        </Fade>

    )
}

export default NewPassword
