import Textbox from "../../component/Textbox/page"

const CoursePercentage = ({ data, method }) => {

    const subjects = ['math', 'science', 'english', 'readingComprehension']

    return (
        <div>
            {
                subjects.map(subject => {
                    return (
                        <div key={subject} style={{margin: '5px 0px'}}>
                            <Textbox
                                id={subject}
                                title={subject}
                                value={String(data[subject])}
                                method={method}
                                
                            />
                        </div>

                    )
                })
            }
        </div>
    )
}

export default CoursePercentage
