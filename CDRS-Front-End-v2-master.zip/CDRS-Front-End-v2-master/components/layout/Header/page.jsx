//Dependencies
import { Link } from 'react-router-dom'

import EditIcon from '@mui/icons-material/ModeEditOutlineRounded';
import AddIcon from '@mui/icons-material/Add';

import './style.css'

export default function Header(props) {
    const { Function, Title, Add, Edit, Text, ViewText } = props

    return (
        <div>
            <div className='Header-body'>
                <div>
                    <p className="Header-title">   {
                            Function == "Add" ? `Add ` :
                                Function == "Edit" ? `Edit ` :
                                    `List of `
                        } 
                        {Title}</p>
                    <p className="Header-subtext">
                        {
                            Function == "Add" ? `Add a records of ${Text}` :
                                Function == "Edit" ? `Update the details and other information of a ${Text}` :
                                    `View all the records of ${ViewText}`
                        }
                    </p>
                </div>
                <div className='Header-button-group'>
                    {Add &&
                        <Link to="Add/0" style={{ textDecoration: "none" }}>
                            <button className="Header-button-add">
                                <AddIcon sx={{ fontSize: "22px" }} />Add {Text}
                            </button>
                        </Link>
                    }
                    {Edit &&
                        <Link to="Edit" style={{ textDecoration: "none" }}>
                            <button className="Header-button-edit">
                                <EditIcon sx={{ fontSize: "22px" }} />Edit {Text}
                            </button>
                        </Link>
                    }
                </div>
            </div>
        </div >
    )
}