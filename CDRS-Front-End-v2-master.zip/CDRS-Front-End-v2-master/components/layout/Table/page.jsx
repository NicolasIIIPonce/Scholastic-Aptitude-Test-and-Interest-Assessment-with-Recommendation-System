import * as React from 'react';
import { useEffect, useState } from 'react';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import Grow from '@mui/material/Grow';
import ComboBox from '../../component/ComboBox/page';
import dataset from '../../../services/datasets/admin.dataset'

import "./style.css"
import { getUrl } from '../../../services/functions/global_function';

export default function Data_Table(props) {

    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };

    const subjects = ["MathQuestion", "ScienceQuestion", "EnglishQuestion", "ReadingQuestion"]
    const field = subjects.includes(getUrl(1))? dataset.subjects.SearchList : dataset[getUrl(1)].SearchList

    return (
        <Grow in={true} timeout={600}>
            <div className="Student_Info">
                <div className="Student_Info_container">
                    <div className="S_Info_header">
                        <div className='Search-tab-group'>
                            <div style={{width: '150px'}}>
                                <ComboBox id="searchfield" value={props.Field} method={props.ChangeField()} list={field} />
                            </div>
                            <input type='text' placeholder={`Search for ${props.Field}`} maxLength={60} className='dialog_body_input' onChange={props.OnChange()} disabled={props.Field == 'All'} value={props.Text}/>
                            {/* <button onClick={props.Search()} className='Header-button-add' style={{padding: '5px 25px'}}>Search</button> */}
                        </div>
                    </div>
                    <TableContainer>
                        <Table>
                            <TableHead>
                                <TableRow sx={{ boxShadow: "box-shadow: rgba(17, 17, 26, 0.1) 0px 1px 0px;" }}>
                                    {props.Column.map((column) => {
                                        const { id, label, align, minWidth } = column

                                        return (
                                            <TableCell
                                                key={id}
                                                align={align}
                                                style={{
                                                    minWidth: minWidth,
                                                    backgroundColor: "rgb(67, 160, 71,0.1)",
                                                }}
                                            >
                                                <div
                                                    className="table_p1"
                                                    style={{
                                                        justifyContent: align
                                                    }}
                                                >
                                                    {label}
                                                </div>

                                            </TableCell>
                                        )
                                    }
                                    )}
                                </TableRow>
                            </TableHead>
                            <TableBody >
                                {props.Row.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => {
                                    return (
                                        <TableRow role="checkbox" tabIndex={-1} key={index}
                                            sx={{
                                                '& td, & th': { borderBottom: "1.5px solid rgb(233, 236, 239,0.6)" },
                                                "&:hover": {
                                                    backgroundColor: "rgb(67, 160, 71,0.026)"
                                                }
                                            }}>
                                            {
                                                props.Column.map((column) => {
                                                    const value = row[column.id];
                                                    return (
                                                        <TableCell key={column.id} align={column.align}>
                                                            <div
                                                                className="table_p2"
                                                                style={{
                                                                    fontWeight: column.id === "Student_Name" ?
                                                                        "600" : "400",
                                                                }}
                                                            >{
                                                                    props.Function(column.id, row, index)
                                                                    // console.log(column.id, index, value, row)
                                                                }</div>
                                                        </TableCell>
                                                    );
                                                })}
                                        </TableRow>
                                    );
                                })}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <TablePagination
                        rowsPerPageOptions={[5, 10, 25]}
                        component="div"
                        count={props.Row.length}
                        rowsPerPage={rowsPerPage}
                        page={page}
                        onPageChange={handleChangePage}
                        onRowsPerPageChange={handleChangeRowsPerPage}
                    />
                </div>
                {/* <button tton onClick={() => window.scrollTo(0, 0)}>top</button> */}
                {props.Dialog}
            </div>
        </Grow >
    );
}
