
import React from "react";
import { Link } from "react-router-dom";

import Logo from "../../../src/icon/logo.png"

import NotificationsRoundedIcon from '@mui/icons-material/NotificationsRounded';
import GroupRoundedIcon from '@mui/icons-material/GroupRounded';
import { IconButton, Avatar, Badge } from "@mui/material";
import Tooltip from '@mui/material/Tooltip';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';

export default function AdminNavbar() {
    
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    return (
        <div className="Admin_Navbar">
            <div>
                <img src={Logo} className="A_Navbar_logo" />
            </div>
            <div className="A_Navbar_div1">
                <Tooltip title="Admin Profile">
                    <Avatar sx={{ backgroundColor: 'rgba(78, 127, 56, 0.85)', cursor: 'pointer' }} onClick={handleClick}></Avatar>
                </Tooltip>
            </div>
            <Menu
                id="basic-menu"
                anchorEl={anchorEl}
                open={open}
                onClose={handleClose}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                transformOrigin={{ vertical: 'top', horizontal: 'left' }}
            >
                <Link to="/" style={{ textDecoration: 'none' }}>
                    <MenuItem onClick={handleClose}>
                        <p className='Menu_p1'>Sign Out</p>
                    </MenuItem>
                </Link>
            </Menu>
        </div >
    )
}
