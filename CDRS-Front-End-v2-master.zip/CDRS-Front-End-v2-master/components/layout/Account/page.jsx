import Data from '../../../services/datasets/global.dataset'

import { Grid, Fade } from "@mui/material";

const Account = ({ title, text, data }) => {
  const { account } = Data.Profile

  return (
    <Fade in={true} timeout={1000}>
      <div>
        <div className="Profile-tab-title-container">
          <div className="Profile-tab-title">
            <p>{title}</p>
            <p>{text}</p>
          </div>
        </div>
        <Grid container rowSpacing={2} columnSpacing={{ xs: 1, sm: 2, md: 0 }}>
          {
            account.map((value, index) => {
              const { id, label } = value
              return (
                <Grid item xs={12} md={6} key={index}>
                  <p className="Profile-tab-label">{label}</p>
                  <input type="text" className="Profile-tab-input" disabled={true} name={id} value={data[id] || ''} />
                </Grid>
              )
            })
          }
        </Grid>
      </div>
    </Fade>
  )
}

export default Account