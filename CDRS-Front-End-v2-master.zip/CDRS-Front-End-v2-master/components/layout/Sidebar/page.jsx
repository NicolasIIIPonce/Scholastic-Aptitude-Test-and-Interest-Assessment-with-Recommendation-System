import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import ListItemButton from '@mui/material/ListItemButton';
import SignalCellularAltRoundedIcon from '@mui/icons-material/SignalCellularAltRounded';
import TaskRoundedIcon from '@mui/icons-material/TaskRounded';
import ArticleRoundedIcon from '@mui/icons-material/ArticleRounded';
import FeedRoundedIcon from '@mui/icons-material/FeedRounded';
import FolderSharedRoundedIcon from '@mui/icons-material/FolderSharedRounded';
import InterestsRoundedIcon from '@mui/icons-material/InterestsRounded';
import NoteAltRoundedIcon from '@mui/icons-material/NoteAltRounded';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import Collapse from '@mui/material/Collapse';

import { getUrl } from "../../../services/functions/global_function";


export default function Sidebar(props) {

    const navigate = useNavigate()
    const Fields = [
        { Title: "Student Information", Icon: <FolderSharedRoundedIcon />, Link: "StudentInformation" },
        { Title: "Course Information", Icon: <ArticleRoundedIcon />, Link: "CourseInformation" },
        {
            Title: "Examination", Icon: <FeedRoundedIcon />, Link: "Examination",
            Lists: [
                { Title: "Exam Information", Link: "Examination" },
                { Title: "Math Questions", Link: "MathQuestion" },
                { Title: "Science Questions", Link: "ScienceQuestion" },
                { Title: "English Questions", Link: "EnglishQuestion" },
                { Title: "Reading Comprehension Questions", Link: "ReadingQuestion" },
            ],
        },
        { Title: "Interest Assessment", Icon: <TaskRoundedIcon />, Link: "IAQuestion" },
        {
            Title: "Student Results", Icon: <NoteAltRoundedIcon />, Link: "Result",
            Lists: [
                { Title: "Entrance Exam Results", Link: "satExamResult" },
                { Title: "Interest Assessment Results", Link: "iaExamResult" },
                { Title: "OverAll Results", Link: "overallResult" },
            ],
        },
    ]

    let act

    const [expanded, setExpanded] = useState(-1)

    const onhandleClick = (link, index) => () => {

        if (index == 2 || index == 4) {
            setExpanded(prev => prev == index ? -1 : index)
        }else {
            navigate(link)
            location.reload()
        }
    }

    return (
        <div className="Admin_Sidebar" >
            <div className="A_Sidebar_header">
                <div className="A_Sidebar_header_box">
                    <p className="A_Sidebar_header_p1">Admin</p>
                    <p className="A_Sidebar_header_p2">Dashboard</p>
                </div>
            </div>
            <div className="A_Sidebar_list_container">
                {
                    Fields.map((field, index) => {
                        const { Title, Icon, Link, Lists } = field
                        act = props.Active === Link

                        return (
                            <div key={index}>
                                <ListItemButton onClick={onhandleClick(Link, index)}
                                    sx={{
                                        borderRadius: "10px",
                                        margin: "10px 0px 0px",
                                        color: act ? "white" : "#9da4ae",
                                        display: "flex",
                                        gap: "15px",
                                        alignItems: "center",
                                        justifyContent: 'space-between',
                                        backgroundColor: act ? "rgb(67, 160, 71,0.2)" : "none",
                                        "&:hover": {
                                            backgroundColor: "rgb(67, 160, 71,0.2)"
                                        }
                                    }}
                                >
                                    <div style={{ display: "flex", gap: "15px" }}>
                                        <div style={{ color: act ? "#4caf50" : "#9da4ae" }}>{Icon}</div>
                                        <p className="Admin_List_p1">{Title}</p>
                                    </div>
                                    {Lists && (expanded == index ? <ExpandLess /> : <ExpandMore />)}
                                </ListItemButton>
                                {
                                    Lists &&
                                    <Collapse in={expanded == index} timeout="auto" unmountOnExit>
                                        {
                                            Lists.map((list, index) => {
                                                const nav = list.Link == "Examination"? Link : `${Link}/${list.Link}`
                                                return (
                                                    <ListItemButton
                                                        key={index}
                                                        sx={{ pl: 7, color: list.Link == getUrl(1) ? "white" : "#9da4ae", }}
                                                        onClick={onhandleClick(nav)}>
                                                        <p className="Admin_List_p1">{list.Title}</p>
                                                    </ListItemButton>
                                                )
                                            })}
                                    </Collapse>
                                }

                            </div>
                        )
                    }
                        // val.Title === "Student Results" ?
                        //     <div key={index}>
                        //         <ListItemButton onClick={handleopentab}
                        //             sx={{
                        //                 borderRadius: "10px",
                        //                 margin: "10px 0px 0px",
                        //                 color: act1 ? "white" : "#9da4ae",
                        //                 display: "flex",
                        //                 gap: "15px",
                        //                 alignItems: "center",
                        //                 justifyContent: 'space-between',
                        //                 backgroundColor: act1 ? "rgb(67, 160, 71,0.2)" : "none",
                        //                 "&:hover": {
                        //                     backgroundColor: "rgb(67, 160, 71,0.2)"
                        //                 }
                        //             }}
                        //         >
                        //             <div style={{ display: "flex", gap: "15px" }}>
                        //                 <div style={{ color: act1 ? "#4caf50" : "#9da4ae" }}>{val.Icon}</div>
                        //                 <p className="Admin_List_p1">{val.Title}</p>
                        //             </div>
                        //             {expanded ? <ExpandLess /> : <ExpandMore />}
                        //         </ListItemButton>
                        //         <Collapse in={expanded} timeout="auto" unmountOnExit>
                        //             {val.tab.map((sub, index) => {
                        //                 return (
                        //                     <Link to={`Student_Results/${sub.Link2}`} style={{ textDecoration: "none" }} key={index} state={{ name: sub.sub }}>
                        //                         <ListItemButton sx={{ pl: 7, color: sub.Link2 === props.Active.text ? "white" : "#9da4ae", }} onClick={() => props.handleClick(sub.Link2, val.Link)}>
                        //                             <p className="Admin_List_p1">{sub.sub}</p>
                        //                         </ListItemButton>
                        //                     </Link>
                        //                 )
                        //             })}
                        //         </Collapse>
                        //     </div>
                        //     :
                        //     <Link to={val.Link} style={{ textDecoration: "none", color: "inherit" }} key={index}>
                        //         <ListItemButton
                        //             name={val.Title}
                        //             sx={{
                        //                 borderRadius: "10px",
                        //                 margin: "10px 0px",
                        //                 color: act ? "white" : "#9da4ae",
                        //                 display: "flex",
                        //                 gap: "15px",
                        //                 alignItems: "center",
                        //                 backgroundColor: act ? "rgb(67, 160, 71,0.2)" : "none",
                        //                 "&:hover": {
                        //                     backgroundColor: "rgb(67, 160, 71,0.2)"
                        //                 }
                        //             }}
                        //             onClick={() => props.handleClick(val.Link)}
                        //         >
                        //             <div style={{ color: act ? "#4caf50" : "#9da4ae", display: "flex" }}>{val.Icon}</div>
                        //             <p className="Admin_List_p1">{val.Title}</p>
                        //         </ListItemButton>
                        //     </Link>
                    )}
            </div>
        </div >
    )
}
