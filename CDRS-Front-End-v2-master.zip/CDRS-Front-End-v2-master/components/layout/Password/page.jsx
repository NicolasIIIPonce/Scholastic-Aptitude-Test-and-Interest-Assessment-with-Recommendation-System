import { useRef, useState } from 'react';

import Data from '../../../services/datasets/global.dataset'
import { validation, limitation, confirmpass } from "../../../services/functions/validation";
import { UserChecking, UpdateUserPassword } from '../../../services/api/User';

import Button from '@mui/material/Button';
import { Grid, Fade } from "@mui/material";
import Snackbar from '../../component/Snackbar/page'
import On from '@mui/icons-material/RemoveRedEyeOutlined';
import Off from '@mui/icons-material/VisibilityOffOutlined';
import IconButton from '@mui/material/IconButton';

const save_btn_sx = {
  backgroundColor: "#69b96eff",
  color: "white",
  fontFamily: "Poppins",
  letterSpacing: "1px",
  textTransform: "none",
  border: "1.5px solid #69b96eff",
  mr: "15px",
  padding: "6px 20px",
  transition: "0.3s",
  fontSize: "13px",

  "&:hover": {
    backgroundColor: "rgb(56, 142, 60,0.9)",
  }
}

const icon_sx = {
  position: "absolute",
  top: 0,
  right: "50px",
  cursor: "pointer",
}

const Account = ({ title, text, data }) => {

  const userlrn = JSON.parse(sessionStorage.getItem('userlrn'))

  const { password } = Data.Profile
  const [open, setopen] = useState(false)

  const passwordform = useRef({
    current: '',
    password: '',
    confirm: '',
  })

  const [Dataform, setDataform] = useState(passwordform.current)
  const [valText, setvalText] = useState(passwordform.current)

  const [show, setshowpass] = useState({ password: false, confirm: false })

  const onChange = (event) => {
    const { name, value } = event.target

    if (name === "password" && (limitation(name, value) || value == "")) {
      setDataform(prev => ({
        ...prev,
        [name]: value
      }))
    } else if (name !== "password") {
      setDataform(prev => ({
        ...prev,
        [name]: value
      }))
    }
    setvalText(prev => ({ ...prev, [name]: value == "" ? 'Please fill in this required fields.' : false }))
  }

  const onSubmit = async () => {
    const currpass = await UserChecking(userlrn, Dataform.current)
    const passvalid = validation('password', Dataform.password, true)
    const confirmvalid = confirmpass(Dataform.password, Dataform.confirm)

    setvalText(() => ({
      current: currpass ? 'success' : 'Incorrect Password',
      password: passvalid,
      confirm: confirmvalid,
    }))

    if (currpass == true && passvalid === "success" && confirmvalid === "success") {
      const res = await UpdateUserPassword(userlrn, Dataform.password)

      setopen(true)
      setDataform(passwordform.current)
    }
  }

  return (
    <Fade in={true} timeout={1000}>
      <div>
        <div className="Profile-tab-title-container">
          <div className="Profile-tab-title">
            <p>{title}</p>
            <p>{text}</p>
          </div>
        </div>
        <Grid container rowSpacing={2} columnSpacing={{ xs: 1, sm: 2, md: 0 }}>
          {
            password.map((value, index) => {
              const { id, label } = value

              return (
                <Grid item xs={12} md={6} key={index}>
                  {
                    index != 1 &&
                    <div>
                      <p className="Profile-tab-label">{id}</p>
                      <div style={{ position: 'relative' }}>
                        <input
                          type={show[id] ? "text" : "password"}
                          className="Profile-tab-input"
                          name={id}
                          value={Dataform[id]}
                          onChange={onChange}
                        />
                        {
                          id !== 'current' &&
                          <IconButton sx={icon_sx} onClick={() => setshowpass(prev => ({ ...prev, [id]: !prev[id] }))}>
                            {show[id] ?
                              <On sx={{ color: '#6c757d' }} />
                              :
                              <Off sx={{ color: '#6c757d' }} />
                            }
                          </IconButton>
                        }
                      </div>

                      {
                        valText[id] !== "success" &&
                        <p
                          className="Login-Form-validation"
                          style={{
                            marginTop: '5px',
                            height: valText[id] ? "15px" : "0px"
                          }}>
                          {valText[id]}
                        </p>
                      }
                    </div>
                  }
                </Grid>
              )
            })
          }
        </Grid>

        <div className="Profile-tab-btn-container">
          <Button sx={save_btn_sx} onClick={onSubmit}>Update Password</Button>
        </div>
        <Snackbar open={open} method={() => setopen(false)} text="Update successful" color="success" vertical="top" horizontal="center" />
      </div>
    </Fade>
  )
}

export default Account