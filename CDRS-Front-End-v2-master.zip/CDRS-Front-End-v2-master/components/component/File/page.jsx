const File = ({method}) => {
    return (
        <>
            <input 
                type="file" 
                onChange={method}
                name="headerPicture"
            ></input>
        </>
    )
}

export default File