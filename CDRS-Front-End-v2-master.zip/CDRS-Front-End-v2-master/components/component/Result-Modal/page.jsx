import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Grow from '@mui/material/Grow';

import check from "../../../src/icon/exam.png"
import "./style.css"

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Grow {...props}/>;
});

export default function AlertDialog({ open, close }) {

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    return (
        <Dialog
            open={open}
            TransitionComponent={Transition}
            onClose={close}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
        >
            <DialogContent>
                <div className='result-modal-div'>
                    <img src={check} className='result-modal' />
                    <h1>Congratulations</h1>
                    <p>You've finish taking the exam. Keep up the great work!</p>
                    <button onClick={close}>Continue</button>
                </div>

            </DialogContent>
        </Dialog>
    );
}