import { useState } from 'react';

import IconButton from '@mui/material/IconButton';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';

const icon_sx = {
  position: 'absolute',
  right: 1,
  top: 0,
}

const PasswordField = ({ id, title, value, method, random, min }) => {
  const [show, setshow] = useState(false)

  return (
    <div className="password-container">
      <div style={{ position: 'relative', width: '100%' }}>
        <input
          type={show ? "text" : "password"}
          className={`Forms-input ${random && 'flex-password'}`}
          style={{ padding: '10px 0px', position: 'relative' }}
          placeholder={title}
          value={value || ''}
          onChange={method}
          name={id}
          pattern={`.{${min},240}`}
          maxLength={16}
          title={`Minlength must be ${min}`}
        />
        <IconButton sx={icon_sx} onClick={() => setshow(prev => !prev)}>
          {show ? <VisibilityOffIcon /> : <VisibilityIcon />}
        </IconButton>
      </div>
      {
        random && <input type="button" name="randomaccess" onClick={method} className='random-button' value="Random"></input>
      }

    </div>
  )
}

export default PasswordField
