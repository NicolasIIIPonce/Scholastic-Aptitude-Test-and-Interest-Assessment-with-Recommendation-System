const TextArea = ({ id, title, value, method, id1}) => {
    return (
        <>
            <textarea
                name={id}
                className="Forms-input"
                style={{ height: "100px" }}
                placeholder={title}
                value={value || ''}
                onChange={method}
                id={id1 == null? id : id1}
                required
            /></>
    )
}

export default TextArea