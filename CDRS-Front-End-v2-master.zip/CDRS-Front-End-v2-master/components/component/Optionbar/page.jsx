//Dependencies
import { Link } from "react-router-dom";
import { useState } from "react";

// Material UI
import * as material from "@mui/material";
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import MoreVertRoundedIcon from '@mui/icons-material/MoreVertRounded';
import EditRoundedIcon from '@mui/icons-material/EditRounded';
import DeleteRoundedIcon from '@mui/icons-material/DeleteRounded';


//CSS Styles
const menuitem_sx = {
    display: 'flex',
    gap: '10px',
    alignItems: 'center',
    fontSize: '14px',
    padding: '6px 20px',
    borderRadius: '5px',
    fontFamily: "Inter",
    fontWeight: '500',
    letterSpacing: '0.5px',

    '&:hover': {
        backgroundColor: '#f6f6f7'
    }
}

export default function Optionbar({ id, handleDelete}) {
    const [anchorEl, setAnchorEl] = useState(null);
    const openaction = Boolean(anchorEl);

    const handleClickAction = (id) => (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleCloseAction = () => {
        setAnchorEl(null);
    };

    const handleClickdelete = () => {  
        handleDelete(id)
        setAnchorEl(null);
    };
    
    return (
        <>
            <material.IconButton onClick={handleClickAction()}>
                <MoreVertRoundedIcon sx={{ fontSize: "19px" }} />
            </material.IconButton>
            <Menu
                elevation={0}
                anchorEl={anchorEl}
                open={openaction}
                onClose={handleCloseAction}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                transformOrigin={{ vertical: 'center', horizontal: 'left' }}
                PaperProps={{
                    style: {
                        padding: '0px 5px',
                        borderRadius: "10px",
                        border: '1px solid #e9ecef',
                        boxShadow: 'rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, 0, 0.06) 0px 1px 2px 0px',
                    }
                }}
            >
                <Link to={`Edit/${id}`} style={{ textDecoration: "none" }}>
                    <span style={{ color: '#252a35' }}>
                        <MenuItem sx={menuitem_sx} onClick={handleCloseAction}>
                            <EditRoundedIcon sx={{ fontSize: "19px" }} />
                            Edit
                        </MenuItem>
                    </span>
                </Link>
                <span style={{ color: '#db514cff' }}>
                    <MenuItem sx={menuitem_sx} onClick={handleClickdelete}>
                        <DeleteRoundedIcon sx={{ fontSize: "19px" }} />
                        Delete
                    </MenuItem>
                </span>
            </Menu>
        </>
    )
}