const Textbox = ({ id, title, value, method, disabled, min, id1 }) => {
    return (
        <input
            type="text"
            className="Forms-input"
            style={{ padding: '10px 0px' }}
            placeholder={title}
            value={value || ''}
            onChange={method}
            name={id}
            disabled={disabled}
            minLength={min}
            pattern={`.{${min},240}`}
            title={`Minlength must be ${min}`}
            id={id1 == null ? '' : id1}
            required
        />
    )
}

export default Textbox