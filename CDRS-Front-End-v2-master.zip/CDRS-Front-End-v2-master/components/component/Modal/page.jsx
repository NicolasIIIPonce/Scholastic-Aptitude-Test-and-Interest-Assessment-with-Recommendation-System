import React, { useState } from 'react';

import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Slide from '@mui/material/Slide';
import IconButton from '@mui/material/IconButton';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

import './style.css'

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

const Modal = ({ open, instruction, cancel, submit, input, remove }) => {

    const [text, settext] = useState()
    const [showPassword, setShowPassword] = useState(false);

    const onchange = (event) => {
        const { value } = event.target
        if (value.length <= 16) {
            settext(event.target.value)
        }
    }

    const Onsubmit = () => {
        submit(text)
        settext('')
    }
    return (
        <Dialog
            open={open}
            TransitionComponent={Transition}
            keepMounted
            fullWidth={true}
            maxWidth={instruction.size}
        >
            <DialogTitle><p className='SignOut-title'>{instruction.title}</p></DialogTitle>
            <DialogContent>
                <DialogContentText id="alert-dialog-slide-description">
                    <span className='SignOut-text'>{instruction.description}</span>
                </DialogContentText>
                <div>
                    {
                        input &&
                        <FormControl sx={{mt: 2 }} variant="outlined" color='success'>
                            <InputLabel htmlFor="outlined-adornment-password" color='success'>Access Code</InputLabel>
                            <OutlinedInput
                                id="outlined-adornment-password"
                                type={showPassword ? 'text' : 'password'}
                                endAdornment={
                                    <InputAdornment position="end">
                                        <IconButton
                                            onClick={() => setShowPassword(prev => !prev)}
                                            edge="end"
                                        >
                                            {showPassword ? <VisibilityOff /> : <Visibility />}
                                        </IconButton>
                                    </InputAdornment>
                                }
                                label="Access Code"
                                color="success"
                                onChange={onchange}
                                value={text || ''}
                            />
                        </FormControl>
                    }
                </div>
            </DialogContent>
            <DialogActions>
                {!remove && <button onClick={cancel} className='SignOut-cancel-button'>Cancel</button>}
                <button onClick={input ? Onsubmit : submit} className='SignOut-confirm-button'>Confirm</button>
            </DialogActions>
        </Dialog>
    )
}

export default Modal 