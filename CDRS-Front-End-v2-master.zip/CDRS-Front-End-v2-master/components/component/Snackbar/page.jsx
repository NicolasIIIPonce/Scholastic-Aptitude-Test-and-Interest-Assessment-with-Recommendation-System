import * as React from 'react';
import Snackbar from '@mui/material/Snackbar';
import Slide from '@mui/material/Slide';
import MuiAlert from '@mui/material/Alert';
import Grow from '@mui/material/Grow';

const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

function SlideTransition(props) {
    return <Slide {...props} direction="up" />;
}

function GrowTransition(props) {
    return <Grow {...props} />;
}

const notificationbar = ({ open, method, text, color, vertical, horizontal }) => {
    const top = vertical == "top"
    return (
        <Snackbar
            open={open}
            autoHideDuration={3500}
            onClose={method}
            TransitionComponent={top ? GrowTransition : SlideTransition}
            anchorOrigin={{ vertical, horizontal }}
        >
            <Alert onClose={method} severity={color} sx={{ width: '100%' }}>
                {text}
            </Alert>
        </Snackbar>
    )
}

export default notificationbar