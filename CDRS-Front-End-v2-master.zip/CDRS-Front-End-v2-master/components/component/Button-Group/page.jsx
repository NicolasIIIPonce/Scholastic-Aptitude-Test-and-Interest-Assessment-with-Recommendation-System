//Dependencies
export default function ButtonGroup({onSubmit, cancel, url, validation}) {

    return (
        <div className="Forms-button-group">
            <input
                type="submit"
                className="Forms-button-save"
                // onClick={onSubmit}
                value={url=='Add'? 'Create': 'Update'}
                disabled={validation != ''? true : false}
            />

            <input type="button" className="Forms-button-cancel" value="Cancel" onClick={cancel}/>
        </div>
    )
}