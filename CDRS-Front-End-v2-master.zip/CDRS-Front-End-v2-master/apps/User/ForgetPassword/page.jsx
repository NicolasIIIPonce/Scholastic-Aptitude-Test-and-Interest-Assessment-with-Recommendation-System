
import "./style.css"
import Alert from '@mui/material/Alert';
import Button from '@mui/material/Button';
import { Link } from 'react-router-dom';
import {useState } from "react"
import Logo from "../../../src/icon/logo.png"
import { Zoom } from "@mui/material";
import Grid from '@mui/material/Grid';
import { validation, limitation } from "../../../services/functions/validation";
import globalDataset from "../../../services/datasets/global.dataset";
import { UserSearchAll,UserChecking } from "../../../services/api/User";
import NewPassword from '../../../components/layout/New-Password/page'

const SignUp_btn = {
    padding: "7px 0px",
    width: "100%",
    backgroundColor: "rgb(56, 142, 60)",
    fontFamily: "'Poppins', sans-serif",
    fontSize: "15px",
    boxShadow: "rgba(149, 157, 165, 0.2) 0px 8px 24px",
    borderRadius: "20px",
    textTransform: "none",
    margin: "35px 0px 15px",
    color: "white",
    letterSpacing: "1px",
    border: "0px",

    "&:hover": {
        backgroundColor: "#2e7d32"
    }
}

export default function Login() {

    const data = globalDataset.SignUp.dataform

    const [notification, setnotification] = useState(false)
    const [Dataform, setDataform] = useState(data)
    const [valtext, setvaltext] = useState(data)
    const [CheckingUser, setCheckingUser] = useState(false)

    const notification_sx = {
        margin: notification ? "20px 0px 10px" : "0px",
        height: notification ? "50px" : "0px"
    }

    async function SubmitForm() {
        const validationfield = Object.keys(Dataform).slice(0, 4).map(values => validation(values, Dataform[values]))

        Object.keys(Dataform).slice(0, 4).map((values, index) => {
            setvaltext(prev => ({
                ...prev,
                [values]: validationfield[index]
            }))
        })

        if (validationfield.every(field => field == "success")) {
            const fetch = await UserSearchAll(Dataform)
            const check = await UserChecking(Dataform.lrn, 'na')


            if (fetch == null || check) {
                setnotification(true)
                setDataform(data)
                setTimeout(() => { setnotification(false) }, 2000)
            } else {
                setCheckingUser(prev => !prev)
                setnotification(false)
            }
        }
    }

    const handlechange = (event) => {
        const { name, value } = event.target

        if (limitation(name, value) || value === "") {
            setDataform(prev => ({
                ...prev,
                [name]: value
            }))

            setvaltext(prev => ({ ...prev, [name]: value == "" ? 'Please fill in this required fields.' : false }))
        }
        setnotification(false)
    }

    const fields = [
        { id: "firstname", label: "FirstName", grid: 6 },
        { id: "lastname", label: "LastName", grid: 6 },
        { id: "lrn", label: "Learning Reference No. (LRN)", grid: 12 },
        { id: "section", label: "Section", grid: 12 },
    ]

    const instruction = {
        instruc1: 'Input your Firstname, Lastname, lrn, and your section to check if the information is in our system.',
        instruc2: 'Please enter your new password. Password must be at least 8 characters, one uppercase letter, one lowercase letter, and one number.'
    }

    return (
        <main className='main-background'>
            <div className='Topbar' />
            <Zoom in={true} timeout={1000}>
                <form>
                    <div className="Sign_Up_box">
                        <img src={Logo} className="Sign_logo"></img>
                        <h1 className="Sign_h1">{!CheckingUser ? 'Forget Password' : 'Create New Password'}</h1>
                        <p className="Sign_p">{!CheckingUser ? instruction.instruc1 : instruction.instruc2}</p>
                        <div>
                            {
                                !CheckingUser ?
                                    (
                                        <>
                                            <div className="Login-Form-notification" style={notification_sx}>
                                                <Alert
                                                    variant="outlined"
                                                    onClose={() => setnotification(false)}
                                                    sx={{ backgroundColor: "#d32f2f0d" }}
                                                    severity="error"
                                                >
                                                    <span>You dont have account in our system</span>
                                                </Alert>
                                            </div>
                                            <Grid container rowSpacing={1.5} columnSpacing={2}>
                                                {
                                                    fields.map((field) => {
                                                        const { id, label, grid } = field

                                                        return (
                                                            <Grid item xs={grid} key={id}>
                                                                <label className="Sign_label">{label}</label>
                                                                <input
                                                                    type="text"
                                                                    className="Sign_text_box"
                                                                    placeholder={label}
                                                                    name={id}
                                                                    value={Dataform[id]}
                                                                    onChange={handlechange}
                                                                />
                                                                {
                                                                    valtext[id] != 'success' &&
                                                                    <p
                                                                        className="Login-Form-validation"
                                                                        style={{
                                                                            paddingBottom: valtext[id] ? "2px" : "0px",
                                                                            height: valtext[id] ? "12px" : "0px"
                                                                        }}
                                                                    >
                                                                        <span>{valtext[id]}</span>
                                                                    </p>
                                                                }
                                                            </Grid>
                                                        )
                                                    })
                                                }
                                            </Grid>

                                            <div>
                                                <Button sx={SignUp_btn} className="Sign_btn" onClick={SubmitForm}>Check User</Button>
                                                <p className="Sign_p1"><Link to="/" style={{ textDecoration: "none" }}> Back to Log In</Link></p>
                                            </div>
                                        </>
                                    )
                                    :
                                    (
                                        <NewPassword lrn={Dataform.lrn} />
                                    )
                            }
                        </div>
                    </div>
                </form>
            </Zoom >
        </main>
    )
}
