import { useEffect, useState } from 'react'
import { Outlet } from "react-router-dom"
import { getWindowSize, navbarURL } from '../../../services/functions/global_function'

// import Nav from '../../../components/layout/Navbar/page'
import NewNav from '../../../components/layout/NewNav/page'
import Snackbar from '../../../components/component/Snackbar/page'

import { Fade, Box, Toolbar, CssBaseline } from '@mui/material'

import './style.css'


const Dashboard = () => {
    const [tab, settab] = useState(null)
    const [widowsize, setwindowsize] = useState(getWindowSize())
    const [openSnackbar, setopenSnackbar] = useState(false);

    const toolbarheight = widowsize.width < 600 ? '56px' : "64px"  //56 mobile size 

    const DashboardMain = {
        backgroundColor: 'rgba(229, 242, 219, 0.06)',
        height: `calc(100vh - ${toolbarheight})`,
    }

    const handlesettab = (link) => {
        settab(link)
    }

    useEffect(() => {
        const user = sessionStorage.getItem("user")

        var view = sessionStorage.getItem("view");

        setopenSnackbar(view != null ? true : false)

        settab(navbarURL())

        sessionStorage.removeItem("view")
    }, [])

    return (
        <Fade in={true} timeout={1250}>
            <Box>
                <CssBaseline />
                <div>
                    <NewNav tab={tab} handletab={handlesettab} />
                </div>
                <Box component="main">
                    <Toolbar />
                    <div style={DashboardMain} className='Dashboard-container'>
                        <Outlet />
                        <div className='box'></div>
                    </div>
                    <Snackbar open={openSnackbar} method={()=> setopenSnackbar(false)} text="Login Successful" color="success" vertical="bottom" horizontal="left" />
                </Box>

            </Box>
        </Fade>

    )
}

export default Dashboard