import { useRef, useState } from "react"
import { useNavigate, Link } from 'react-router-dom';

import Logo from "../../../src/icon/logo.png"

import { validation, limitation, confirmpass } from '../../../services/functions/validation'
import { UserChecking, UpdateUserPassword, UserFetch } from '../../../services/api/User'
import NewPassword from '../../../components/layout/New-Password/page'

import Alert from '@mui/material/Alert';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Zoom from "@mui/material/Zoom";

import './style.css'
import { Fade, Grow } from "@mui/material";

const ChangePasswordBtn = {
    width: "100%",
    height: "40px",
    backgroundColor: "#388E3C",
    color: "white",
    fontSize: "16px",
    fontFamily: "'Poppins', sans-serif",
    border: "0px",
    marginTop: "110px",
    boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px",
    borderRadius: "5px",
    textTransform: "none",
    letterSpacing: "1.5px",

    "&:hover": {
        backgroundColor: "#2e7d32"
    }
}

const SignUp = () => {

    const [notification, setnotification] = useState(false)

    const instruction = {
        instruc1: 'Input your LRN to check if you are already log in to our system. if not you will be ridirect in create password form to create your new password for you to log in to system.',
        instruc2: 'Please enter your new password. Password must be at least 8 characters, one uppercase letter, one lowercase letter, and one number.'
    }

    const datainput = useRef({ lrn: ''})
    const [Dataform, setDataform] = useState(datainput.current)

    const [CheckingUser, setCheckingUser] = useState(false)
    const [alerttext, setalerttext] = useState(false)

    const [valText, setvalText] = useState({ lrn: false})

    const notification_sx = {
        margin: notification ? "20px 0px 5px" : "10px",
        height: notification ? "70px" : "0px"
    }

    const handlechange = (event) => {
        const { name, value } = event.target

        if (limitation(name, value) || value === "") {
            setDataform(prev => ({
                ...prev,
                [name]: value
            }))

            setvalText(prev => ({ ...prev, [name]: value == "" ? 'Please fill in this required fields.' : false }))
        }
    }

    async function SubmitForm() {
        const lrnvalid = validation('lrn', Dataform.lrn)

        setvalText(prev => ({
            ...prev,
            lrn: lrnvalid,
        }))

        if (lrnvalid === "success") {
            const fetch = await UserChecking(Dataform.lrn, 'na')

            if (fetch == null || !fetch) {
                setnotification(true)
                setalerttext(fetch == null ? false : true)
                setDataform(datainput.current)
                setTimeout(() => { setnotification(false) }, 2000)
            } else {
                setCheckingUser(prev => !prev)
                setnotification(false)
            }
        }
    }

    return (
        <main className='main-background'>
            <div className='Topbar' />
            <Zoom in={true} timeout={1000}>
                <div className='Login-Form-box'>
                    <img src={Logo} className="Login-Form-logo" />
                    <h1 className="Sign_h1">Create Password</h1>

                    <p className="Sign_p" style={{textAlign: 'center'}}><b>Instruction: </b><span>{CheckingUser ? instruction.instruc2 : instruction.instruc1}</span></p>
                    <div className="Login-Form-notification" style={notification_sx}>
                        <Alert
                            variant="outlined"
                            sx={{ backgroundColor: "#d32f2f0d", display: "flex", alignItems: "center" }}
                            severity={alerttext ? 'warning' : 'error'}
                        >
                            <span>{alerttext ? 'You have already logged into the system.' : 'You dont have account in our system'}</span>
                        </Alert>
                    </div>
                    {
                        !CheckingUser ?
                            (
                                <Grow in={!CheckingUser} timeout={1000}>
                                    <div className="SignUp-Form-box">
                                        <TextField
                                            error={!valText.lrn ? false :
                                                valText.lrn === 'success' ? false : true
                                            }
                                            name="lrn"
                                            label="Learning Reference No. (LRN)"
                                            variant="outlined"
                                            className="Login-Form-input"
                                            color="success"
                                            value={Dataform.lrn}
                                            onChange={handlechange}
                                            InputLabelProps={{
                                                style: {
                                                    color: !valText.lrn ? '#4e7f38ff' :
                                                        valText.lrn === 'success' ? '#4e7f38ff' : 'red'
                                                },
                                            }}
                                            sx={{ margin: '10px 0px 5px' }}
                                        />

                                        {
                                            valText.lrn != 'success' &&
                                            <p
                                                className="Login-Form-validation"
                                                style={{
                                                    paddingBottom: valText.lrn ? "2px" : "0px",
                                                    height: valText.lrn ? "12px" : "0px"
                                                }}
                                            >
                                                <span>{valText.lrn}</span>
                                            </p>
                                        }

                                        <Button variant="contained" onClick={SubmitForm} sx={ChangePasswordBtn} >Check User</Button>
                                        <p className='Login-Form-p1'>Already have a password?<Link to="/" style={{ textDecoration: "none", color: '#4e7f38ff' }}><b> Log In</b></Link></p>
                                    </div>
                                </Grow>
                            )
                            :
                            (
                                <NewPassword lrn={Dataform.lrn} />
                            )
                    }
                </div>
            </Zoom>
        </main>
    )
}

export default SignUp

