import { useEffect, useState } from "react"
import { useNavigate, Link } from 'react-router-dom';

import Logo from "../../../src/icon/logo.png"

import { validation, limitation } from '../../../services/functions/validation'
import { UserChecking } from '../../../services/api/User'
import Snackbar from "../../../components/component/Snackbar/page";

import Alert from '@mui/material/Alert';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import IconButton from '@mui/material/IconButton';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import RemoveRedEyeOutlinedIcon from '@mui/icons-material/RemoveRedEyeOutlined';
import VisibilityOffOutlinedIcon from '@mui/icons-material/VisibilityOffOutlined';
import Zoom from "@mui/material/Zoom";

import './style.css'

const Login_btn = {
    width: "100%",
    backgroundColor: "#388E3C",
    color: "white",
    fontSize: "16px",
    fontFamily: "'Poppins', sans-serif",
    border: "0px",
    marginTop: "110px",
    boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px",
    borderRadius: "5px",
    textTransform: "none",
    letterSpacing: "1.5px",

    "&:hover": {
        backgroundColor: "#2e7d32"
    }
}

const Login = () => {

    const navigate = useNavigate()
    const [opendialog, setopendialog] = useState(false)

    const [notification, setnotification] = useState(false)
    const [showpass, setshowpass] = useState(false)

    const [valText, setvalText] = useState({ lrn: false, password: false })

    const [Dataform, setDataform] = useState({ lrn: '', password: '' })

    const notification_sx = {
        margin: notification ? "20px 0px 10px" : "30px",
        height: notification ? "50px" : "0px"
    }

    const handlechange = (event) => {
        const { name, value } = event.target

        if (limitation(name, value) || value === "") {
            setDataform(prev => ({
                ...prev,
                [name]: value
            }))

            setvalText(prev => ({ ...prev, [name]: value == "" ? 'Please fill in this required fields.' : false }))

        }
        setnotification(false)
    }

    async function SubmitForm() {
        const { lrn, password } = Dataform

        if (lrn == "217" && password == "GoToAdminPage") {
            navigate('/Admin/Login')
        }

        const lrnvalid = validation('lrn', Dataform.lrn)
        const passvalid = validation('password', Dataform.password)

        setvalText(() => ({
            lrn: lrnvalid,
            password: passvalid,
        }))

        if (lrnvalid === "success" && passvalid === "success") {

            const res = await UserChecking(lrn, password)

            if (res) {
                sessionStorage.setItem("userlrn", Dataform.lrn)

                navigate('/Dashboard')
            } else {
                setnotification(true)
                setDataform(prev => ({ ...prev, password: '' }))
            }
        }

        sessionStorage.setItem("view", 1);
    }

    useEffect(() => {
        const changepass = JSON.parse(sessionStorage.getItem('change'))

        if (changepass != null) {
            setopendialog(true)
            sessionStorage.removeItem('change')
        }
    }, [])

    return (
        <main className='main-background'>
            <div className='Topbar' />
            <Zoom in={true} timeout={1000}>
                <div className='Login-Form-box'>
                    <img src={Logo} className="Login-Form-logo" />
                    <h1 className="Login-Form-title">Student Login</h1>

                    <div className="Login-Form-notification" style={notification_sx}>
                        <Alert
                            variant="outlined"
                            onClose={() => setnotification(false)}
                            sx={{ backgroundColor: "#d32f2f0d" }}
                            severity="error"
                        >
                            <span>Incorrect LRN or Password.</span>
                        </Alert>
                    </div>

                    <TextField
                        error={!valText.lrn ? false :
                            valText.lrn === 'success' ? false : true
                        }
                        name="lrn"
                        label="Learning Reference No. (LRN)"
                        variant="outlined"
                        className="Login-Form-input"
                        color="success"
                        value={Dataform.lrn}
                        onChange={handlechange}
                        InputLabelProps={{
                            style: {
                                color: !valText.lrn ? '#4e7f38ff' :
                                    valText.lrn === 'success' ? '#4e7f38ff' : 'red'
                            },
                        }}
                        sx={{ margin: '10px 0px 5px' }}
                    />

                    {
                        valText.lrn != 'success' &&
                        <p
                            className="Login-Form-validation"
                            style={{
                                paddingBottom: valText.lrn ? "2px" : "0px",
                                height: valText.lrn ? "12px" : "0px"
                            }}
                        >
                            <span>{valText.lrn}</span>
                        </p>
                    }

                    <FormControl className="Login-Form-input" sx={{ margin: '10px 0px 5px' }} variant="outlined" >
                        <InputLabel>
                            <p
                                style={{
                                    color: !valText.password ? '#4e7f38ff' :
                                        valText.password === 'success' ? '#4e7f38ff' : 'red'
                                }}
                            >
                                Password
                            </p>
                        </InputLabel>
                        <OutlinedInput
                            error={!valText.password ? false
                                : valText.password === 'success' ? false : true
                            }
                            name="password"
                            type={showpass ? 'text' : 'password'}
                            endAdornment={
                                <InputAdornment position="end">
                                    <IconButton
                                        onClick={() => setshowpass(prev => !prev)}
                                        edge="end"
                                    >
                                        {showpass ? <VisibilityOffOutlinedIcon /> : <RemoveRedEyeOutlinedIcon />}
                                    </IconButton>
                                </InputAdornment>
                            }
                            label="Password"
                            color="success"
                            value={Dataform.password}
                            onChange={handlechange}
                        />
                    </FormControl>
                    <div className="forget-password-div">
                        {
                            valText.password != 'success' ?
                            <p
                                className="Login-Form-validation"
                                style={{
                                    paddingBottom: valText.password ? "2px" : "0px",
                                    height: valText.password ? "12px" : "0px"
                                }}
                            >
                                <span>{valText.password}</span>
                            </p>
                            :
                            <p></p>
                        }
                        <p className='Login-Form-p1' style={{ margin: 0, fontSize: '13px'}}><Link to="/Forget-password" style={{ textDecoration: "none", color: '#4e7f38ff' }}><b>Forget Password?</b></Link></p>
                    </div>

                    <Button variant="contained" onClick={SubmitForm} sx={Login_btn} >Login</Button>
                    <p className='Login-Form-p1'>Dont have password?<Link to="/Create-password" style={{ textDecoration: "none", color: '#4e7f38ff' }}><b> Create password</b></Link></p>
                </div>
            </Zoom>

            <Snackbar open={opendialog} method={() => setopendialog(false)} text="Your password has been changed successfuly" color="success" vertical="bottom" horizontal="left" />
        </main>
    )
}

export default Login