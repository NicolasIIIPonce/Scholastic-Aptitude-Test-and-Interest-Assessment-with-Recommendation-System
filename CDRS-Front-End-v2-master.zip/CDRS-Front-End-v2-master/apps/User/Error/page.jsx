import Image from '../../../src/image/404 Error.svg'
import { useNavigate } from 'react-router-dom'

import './style.css'

export default function Error() {
    const navigate = useNavigate()

    return (
        <div className="ErrorPage">
            <img src={Image} className="Error-image"></img>
            <h1>Ooops! Page Not Found</h1>
            <p>This page doesn't exist or was removed!</p>
            <p>We suggest you back to Back</p>
            <button onClick={() => navigate(-1)}>Go Back</button>
        </div>
    )
}