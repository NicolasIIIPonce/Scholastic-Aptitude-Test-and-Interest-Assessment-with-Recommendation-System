import { BrowserRouter, Route, Routes } from "react-router-dom";

import Login from './User/Login/page';
import SignUp from './User/SignUp/page';
import ForgetPassword from './User/ForgetPassword/page'
import Dashboard from './User/Dashboard/page'

import Main from '../components/pages/Main/page';
import CourseDirectory from '../components/pages/Course-Directory/page';
import IAInformation from '../components/pages/IA-Information/page';
import Examination from '../components/pages/Examination/page';
import Help from '../components/pages/Help/page';
import Profile from '../components/pages/Profile/page';

import SATExam from '../components/pages/SAT/page';
import IAExam from '../components/pages/IA/page';
import Result from '../components/pages/Result/page';
import CourseInformation from "../components/pages/Course-Information/page";

import AdminLogin from './Admin/Login/page';
import AdminDashboard from './Admin/Dashboard/page';

import Content from '../components/layout/Content/page';
import Form from  '../components/layout/Form/page'

import Error from './User/Error/page';

export default function Router() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path='/' element={<Login />} />
                <Route path='Create-password' element={<SignUp />} />
                <Route path='Forget-password' element={<ForgetPassword />} />

                <Route path="Dashboard" element={<Dashboard />}>
                    <Route index path="" element={<Main />} />
                    <Route path="Course-Directory" > 
                        <Route path="" element={<CourseDirectory />} />
                        <Route path=":name" element={<CourseInformation />} />
                    </Route>
                    <Route path="IA-Information" element={<IAInformation />} />
                    <Route path="Examination">
                        <Route path="" element={<Examination />}></Route>
                        <Route path="SAT-Exam">
                            <Route path=":subject/:no" element={<SATExam />}/>
                        </Route>
                        <Route path="IA-Exam">
                            <Route path=":no" element={<IAExam />}/>
                        </Route>
                        <Route path="ExamResult" element={<Result />}></Route>
                    </Route>
                    <Route path="Help" element={<Help />} />
                    <Route path="Profile">
                        <Route path=":id" element={<Profile />} />
                    </Route>
                </Route>

                <Route path="Admin">
                    <Route index path="Login" element={<AdminLogin/>}/>
                    <Route path="Dashboard" element={<AdminDashboard/>}>
                        <Route path=":tabs">
                            <Route index path="" element={<Content/>} />
                            <Route  path=":sub" element={<Content/>} />
                            <Route path=":function/:id" element={<Form/>} />
                            <Route path=":function/:method/:id" element={<Form/>} />
                        </Route>
                    </Route>
                </Route>

                <Route path='*' element={<Error />} />
            </Routes>
        </BrowserRouter>
    )
}