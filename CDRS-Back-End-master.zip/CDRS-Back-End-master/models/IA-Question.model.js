const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const modelschema = new Schema({
    question: {
        type: String,
        required: true,
    },
    hip: {
        type: String,
        required: true,
    },
    
}, {
    timestamps: true,
    versionKey: false
});

const model = mongoose.model('iaquestion', modelschema);

module.exports = model;