const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const modelschema = new Schema({
    question: {
        type: String,
        required: true,
    },
    choiceA: {
        type: String,
        required: true,
    },
    choiceB: {
        type: String,
        required: true,
    },
    choiceC: {
        type: String,
        required: true,
    },
    choiceD: {
        type: String,
        required: true,
    },
    answer: {
        type: String,
        required: true,
    },
    
}, {
    timestamps: true,
    versionKey: false
});


const model = mongoose.model('readingquestions', modelschema);

module.exports = model;