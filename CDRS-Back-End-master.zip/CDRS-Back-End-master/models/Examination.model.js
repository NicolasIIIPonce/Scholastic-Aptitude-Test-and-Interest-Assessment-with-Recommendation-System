const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const modelschema = new Schema({
    section: { 
        type: String 
    },
    accessCode: { 
        type: String 
    },
    minute: { 
        type: Number 
    },
    startDate: { 
        type: String 
    },
    endDate: { 
        type: String 
    },
    status : {
        type: String
    }
}, {
    timestamps: true,
    versionKey: false
});

const model = mongoose.model('examinations', modelschema);

module.exports = model;