const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const modelschema = new Schema({
    field: {
        type: String,
        required: true,
    },
    acronym: {
        type: String,
        required: true,
    },
    courseName: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    headerPicture: {
        type: String,
        required: true,
    },
    courseJob: [
        {
        jobName: {
            type: String,
            required: true,
        },
        description: {
            type: String,
            required: true,
        }
    }
    ],
    interest: {
        type: String,
        required: false,
    },
    coursePercentage: {
        math : { type: Number},
        science: { type: Number},
        english: { type: Number},
        readingComprehension: { type: Number},
    }
        // {
        // subject: {
        //     type: String,
        //     required: true,
        // },
        // percent: {
        //     type: Number,
        //     required: true,
        // },
    // }
    // ],
}, {
    timestamps: true,
    versionKey: false
});

const model = mongoose.model('courseinformation', modelschema);

module.exports = model;