const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const modelschema = new Schema({
    lrn: { type: Number, required: true },
    satExamResult: {
        score: [
            { subject: { type: String }, score: { type: Number }, minute: { type: Number }, second: { type: Number } }
        ],
        total: { type: Number },
        result: { type: String }
    },
    iaExamResult: {
        score: [
            { hip: { type: String }, score: { type: Number } }
        ],
        result: { type: Array }
    },
    overallResult: {
        result: [
            {
                subject: { type: String },
                accuracy: { type: mongoose.Types.Decimal128 },
                average: { type: mongoose.Types.Decimal128 },
                efficiency: { type: mongoose.Types.Decimal128 }, //changed
            }
        ],
        courseRecommended: { type: String }
    }
}, {
    timestamps: true,
    versionKey: false
});

const model = mongoose.model('results', modelschema);

module.exports = model;
