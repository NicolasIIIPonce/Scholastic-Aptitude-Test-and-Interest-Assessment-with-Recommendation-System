const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;

//middleware
app.use(cors());
app.use(express.json());

//mongodb connection
const uri = process.env.ATLAS_URI;
mongoose.connect(uri, {useNewUrlParser: true, useUnifiedTopology: true});

const connection = mongoose.connection;
connection.once('open', ()=>{
    console.log("MongoDB database connection is established.");
});

//Routes
const StudentRouter = require('./routes/Student-Information');
const CourseRouter = require('./routes/Course-Information');
const IAQuestionRouter = require('./routes/IA-Question');
const ExaminationRouter = require('./routes/Examination');
const MathQuestionRouter = require('./routes/Math-Question');
const ScienceQuestionRouter = require('./routes/Science-Question');
const EnglishQuestionRouter = require('./routes/English-Question');
const ReadingQuestionRouter = require('./routes/Reading-Question');
const ResultRouter = require('./routes/Result');

//api
app.use('/StudentInformation', StudentRouter);
app.use('/CourseInformation', CourseRouter);
app.use('/IAQuestion', IAQuestionRouter);
app.use('/MathQuestion', MathQuestionRouter);
app.use('/ScienceQuestion', ScienceQuestionRouter);
app.use('/EnglishQuestion', EnglishQuestionRouter);
app.use('/ReadingQuestion', ReadingQuestionRouter);
app.use('/Result', ResultRouter);
app.use('/Examination', ExaminationRouter);

app.listen(port, (res,req)=> {
    console.log(`Server is running in port: ${port}`);
})