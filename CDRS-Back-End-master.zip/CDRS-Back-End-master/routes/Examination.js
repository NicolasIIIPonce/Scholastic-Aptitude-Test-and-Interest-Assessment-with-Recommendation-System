const router = require('express').Router();

let Examination = require('../models/Examination.model');

//Home or Get
router.route('/').get((req, res) => {
    Examination.find()
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Add
router.route('/add').post((req, res) => {
    const section = req.body.section;
    const accessCode = req.body.accessCode;
    const minute = req.body.minute;
    const second = req.body.second;
    const startDate = req.body.startDate;
    const endDate = req.body.endDate;
    const status = req.body.status;

    const newExamination = new Examination({ section, accessCode, minute, second, startDate, endDate ,status });

    newExamination.save()
        .then(data => res.json("Added Successful"))
        .catch(err => res.status(400).json('Error :' + err));
});

//Search or details
router.route('/:id').get((req, res) => {
    Examination.findById(req.params.id)
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Search for course
router.route('/section/:section').get((req, res) => {
    Examination.find({ section: req.params.section })
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Delete
router.route('/:id').delete((req, res) => {
    Examination.findByIdAndDelete(req.params.id)
        .then(() => res.json("Record was Deleted."))
        .catch(err => res.status(400).json('Error :' + err));
});

//Edit
router.route('/update/:id').post((req, res) => {
    Examination.findById((req.params.id))
        .then(data => {
            data.section = req.body.section;
            data.accessCode = req.body.accessCode;
            data.minute = req.body.minute;
            data.second = req.body.second;
            data.status = req.body.status;
            data.startDate = req.body.startDate;
            data.endDate = req.body.endDate;

            data.save()
                .then(() => res.json('Record Was Updated!'))
                .catch(err => res.status(400).json('Error :' + err));
        })
        .catch(err => res.status(400).json('Error :' + err));
});

//Update Status 
router.route('/status/update/:id').post((req, res) => {
    Examination.updateOne({ "_id": req.params.id },
        {
            $set: {
                "status": req.body.result
            }
        })
        .then(() => res.json("Record update"))
        .catch(err => console.log(err))
});

module.exports = router;