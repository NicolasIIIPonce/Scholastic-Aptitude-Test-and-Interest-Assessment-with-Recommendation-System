const router = require('express').Router();

let Result = require('../models/Result.model');

//Home or Get
router.route('/').get((req, res) => {
    Result.find()
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Add
router.route('/add').post((req, res) => {
    const lrn = req.body.lrn;
    const satExamResult = req.body.satExamResult;
    const iaExamResult = req.body.iaExamResult;
    const overallResult = req.body.overallResult;

    const newResult = new Result({ lrn, satExamResult, iaExamResult, overallResult });

    newResult.save()
        .then(data => res.json("Added Successful"))
        .catch(err => res.status(400).json('Error :' + err));
});

//Search or details
router.route('/:lrn').get((req, res) => {
    Result.find({ lrn: req.params.lrn })
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Delete
router.route('/:id').delete((req, res) => {
    Result.findByIdAndDelete(req.params.id)
        .then(() => res.json("Record was Deleted."))
        .catch(err => res.status(400).json('Error :' + err));
});

// //Edit
// router.route('/update/:id').post((req, res) => {
//     Result.findById((req.params.id))
//         .then(data => {
//             data.lrn = req.body.lrn;
//             data.satExamResult = req.body.satExamResult;
//             data.iaExamResult = req.body.iaExamResult;
//             data.overallResult = req.body.overallResult;

//             data.save()
//                 .then(() => res.json('Record Was Updated!'))
//                 .catch(err => res.status(400).json('Error :' + err));
//         })
//         .catch(err => res.status(400).json('Error :' + err));
// });

//Update SAT Exam
router.route('/sat/update/:lrn').post((req, res) => {
    Result.updateOne({ "lrn": req.params.lrn, "satExamResult.score.subject": req.body.subject },
    {
        $set: {
            "satExamResult.score.$.score": req.body.score,
            "satExamResult.score.$.minute": req.body.minute,
            "satExamResult.score.$.second": req.body.second,
        }
    })
    .then(() => res.json("Record update"))
    .catch(err => console.log(err))
});

//Update SAT Total and result Exam
router.route('/sat/result/update/:lrn').post((req, res) => {
    Result.updateOne({ "lrn": req.params.lrn },
    {
        $set: {
            "satExamResult.total": req.body.total,
            "satExamResult.result": req.body.result,
        }
    })
    .then(() => res.json("Record update"))
    .catch(err => console.log(err))
});

//Update IA Exam
router.route('/ia/update/:lrn').post((req, res) => {
    Result.updateOne({ "lrn": req.params.lrn },
        {
            $set: {
                "iaExamResult.score": req.body.result,
                "iaExamResult.result": req.body.algorith
            }
        })
        .then(() => res.json("Record update (IA Result)"))
        .catch(err => console.log(err))
});

//Update Overall Exam
router.route('/all/update/:lrn').post((req, res) => {
    Result.updateOne({ "lrn": req.params.lrn },
        {
            $set: {
                "overallResult.result": req.body.result,
            }
        })
        .then(() => res.json("Record update (OverALL.result)"))
        .catch(err => console.log(err))
});

module.exports = router;
