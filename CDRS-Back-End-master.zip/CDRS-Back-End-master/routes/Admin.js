const router = require('express').Router();

let StudentInfo = require('../models/Admin.model');

//Home or Get
router.route('/').get((req, res) => {
    StudentInfo.find()
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Add
router.route('/add').post((req, res) => {
    const firstname = req.body.firstname;
    const lastname = req.body.lastname;
    const lrn = req.body.lrn;
    const password = req.body.password;
    const section = req.body.section;
    const examStatus = req.body.examStatus;
    const accountStatus = req.body.accountStatus;

    const newStudentInfo = new StudentInfo({ firstname, lastname, lrn, password, section, examStatus, accountStatus }, { versionKey: false });

    newStudentInfo.save()
        .then(data => res.json("Added Successful"))
        .catch(err => res.status(400).json('Error :' + err));
});

//Search by ID
router.route('/:id').get((req, res) => {
    StudentInfo.findById(req.params.id)
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Search for lrn
router.route('/lrn/:lrn').get((req, res) => {
    StudentInfo.findOne({ lrn: req.params.lrn })
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Search for lrn, firstname, lastname, section
router.route('/searchAll/:lrn').post((req, res) => {
    StudentInfo.findOne(
        {
            lrn: req.params.lrn,
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            section: req.body.section
        })
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Search for lrn and password
router.route('/search/:lrn&:password').get((req, res) => {
    StudentInfo.findOne({ lrn: req.params.lrn })
        .then(data => {
            if (data != null && data.accountStatus !== "Inactive") {
                data.comparePassword(req.params.password, function (err, isMatch) {
                    if (err) throw err;
                    res.json(isMatch)
                });
            } else {
                res.json(null)
            }
        })
        .catch(err => res.status(400).json('Error :' + err));
});

//Delete
router.route('/:id').delete((req, res) => {
    StudentInfo.findByIdAndDelete(req.params.id)
        .then(() => res.json("Record was Deleted."))
        .catch(err => res.status(400).json('Error :' + err));
});

//Edit for the entire user
router.route('/update/:id').post((req, res) => {
    StudentInfo.findByIdAndUpdate(req.params.id)
        .then(data => {
            data.firstname = req.body.firstname;
            data.lastname = req.body.lastname;
            data.lrn = req.body.lrn;
            data.section = req.body.section;
            data.password = req.body.password;
            data.examStatus = req.body.examStatus;
            data.accountStatus = req.body.accountStatus;

            data.save()
                .then(() => res.json('Record Was Updated!'))
                .catch(err => res.status(400).json('Error :' + err));
        })
        .catch(err => res.status(400).json('Error :' + err));
});

//Edit
router.route('/update/lrn/:lrn&:password').post((req, res) => {
    StudentInfo.findOne({ lrn: req.params.lrn })
        .then(data => {
            data.firstname = data.firstname;
            data.lastname = data.lastname;
            data.lrn = data.lrn;
            data.section = data.section;
            data.password = req.params.password;
            data.examStatus = data.examStatus;
            data.accountStatus = data.accountStatus;

            data.save()
                .then(() => res.json('Password Updated'))
                .catch(err => res.status(400).json('Error :' + err));
        })
        .catch(err => res.status(400).json('Error :' + err));
});

//Update the exam status
router.route('/examstatus/update/:lrn').post((req, res) => {
    StudentInfo.updateOne({ "lrn": req.params.lrn },
        {
            $set: {
                "examStatus": "Exam Taken"
            }
        })
        .then(() => res.json("Record update"))
        .catch(err => console.log(err))
});


module.exports = router;