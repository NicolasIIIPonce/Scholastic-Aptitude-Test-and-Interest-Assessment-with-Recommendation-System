const router = require('express').Router();

let CourseInfo = require('../models/Course-Information.model');

//Home or Get
router.route('/').get((req, res) => {
    CourseInfo.find()
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Add
router.route('/add').post((req, res) => {
    const field = req.body.field;
    const acronym = req.body.acronym;
    const courseName = req.body.courseName;
    const description = req.body.description;
    const headerPicture = req.body.headerPicture;
    const interest = req.body.interest;
    const courseJob = req.body.courseJob;
    const coursePercentage = req.body.coursePercentage;

    const newCourseInfo = new CourseInfo({ field, acronym, courseName, description, headerPicture,interest, courseJob, coursePercentage });

    newCourseInfo.save()
        .then(data => res.json("Added Successful"))
        .catch(err => res.status(400).json('Error :' + err));
});

//Search or details
router.route('/:id').get((req, res) => {
    CourseInfo.findById(req.params.id)
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Search for a specific field
router.route('/field/:name').get((req, res) => {
    CourseInfo.find({field: req.params.name})
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Delete
router.route('/:id').delete((req, res) => {
    CourseInfo.findByIdAndDelete(req.params.id)
        .then(() => res.json("Record was Deleted."))
        .catch(err => res.status(400).json('Error :' + err));
});

//Edit
router.route('/update/:id').post((req, res) => {
    CourseInfo.findById((req.params.id))
        .then(data => {
            data.field = req.body.field;
            data.acronym = req.body.acronym;
            data.courseName = req.body.courseName;
            data.description = req.body.description;
            data.headerPicture = req.body.headerPicture;
            data.interest = req.body.interest;
            data.courseJob = req.body.courseJob;
            data.coursePercentage = req.body.coursePercentage;

            data.save()
                .then(() => res.json('Record Was Updated!'))
                .catch(err => res.status(400).json('Error :' + err));
        })
        .catch(err => res.status(400).json('Error :' + err));
});

module.exports = router;