const router = require('express').Router();

let IAQuestion = require('../models/IA-Question.model');

//Home or Get
router.route('/').get((req, res) => {
    IAQuestion.find()
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Add
router.route('/add').post((req, res) => {
    const question = req.body.question;
    const hip = req.body.hip;

    const newIAQuestion = new IAQuestion({ question, hip});

    newIAQuestion.save()
        .then(data => res.json("Added Successful"))
        .catch(err => res.status(400).json('Error :' + err));
});

//Search or details
router.route('/:id').get((req, res) => {
    IAQuestion.findById(req.params.id)
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Delete
router.route('/:id').delete((req, res) => {
    IAQuestion.findByIdAndDelete(req.params.id)
        .then(() => res.json("Record was Deleted."))
        .catch(err => res.status(400).json('Error :' + err));
});

//Edit
router.route('/update/:id').post((req, res) => {
    IAQuestion.findById((req.params.id))
        .then(data => {
            data.question = req.body.question;
            data.hip = req.body.hip;
            data.save()
                .then(() => res.json('Record Was Updated!'))
                .catch(err => res.status(400).json('Error :' + err));
        })
        .catch(err => res.status(400).json('Error :' + err));
});

module.exports = router;