const router = require('express').Router();

let ExamQuestion = require('../models/Science-Question.model');

//Home or Get
router.route('/').get((req, res) => {
    ExamQuestion.find()
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Add
router.route('/add').post((req, res) => {
    const question = req.body.question;
    const choiceA = req.body.choiceA;
    const choiceB = req.body.choiceB;
    const choiceC = req.body.choiceC;
    const choiceD = req.body.choiceD;
    const answer = req.body.answer;

    const newExamQuestion = new ExamQuestion({ question, choiceA, choiceB, choiceC, choiceD, answer });

    newExamQuestion.save()
        .then(data => res.json("Added Successful"))
        .catch(err => res.status(400).json('Error :' + err));
});

//Search or details
router.route('/:id').get((req, res) => {
    ExamQuestion.findById(req.params.id)
        .then(data => res.json(data))
        .catch(err => res.status(400).json('Error :' + err));
});

//Delete
router.route('/:id').delete((req, res) => {
    ExamQuestion.findByIdAndDelete(req.params.id)
        .then(() => res.json("Record was Deleted."))
        .catch(err => res.status(400).json('Error :' + err));
});

//Edit
router.route('/update/:id').post((req, res) => {
    ExamQuestion.findById((req.params.id))
        .then(data => {
            data.question = req.body.question;
            data.choiceA = req.body.choiceA;
            data.choiceB = req.body.choiceB;
            data.choiceC = req.body.choiceC;
            data.choiceD = req.body.choiceD;
            data.answer = req.body.answer;

            data.save()
                .then(() => res.json('Record Was Updated!'))
                .catch(err => res.status(400).json('Error :' + err));
        })
        .catch(err => res.status(400).json('Error :' + err));
});

module.exports = router;